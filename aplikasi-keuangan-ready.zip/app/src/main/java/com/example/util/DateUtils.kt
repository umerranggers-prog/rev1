package com.example.util

import com.example.data.model.TransactionEntity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class MonthYearGroup(
    val key: String, // e.g. "2026-10" for sorting
    val displayTitle: String // e.g. "OKTOBER 2026"
)

data class MonthTransactionGroup(
    val monthYearTitle: String,
    val key: String,
    val transactions: List<TransactionEntity>
)

object DateUtils {
    private val MONTH_NAMES_UPPER = listOf(
        "JANUARI", "FEBRUARI", "MARET", "APRIL", "MEI", "JUNI",
        "JULI", "AGUSTUS", "SEPTEMBER", "OKTOBER", "NOVEMBER", "DESEMBER"
    )

    private val MONTH_SHORT = listOf(
        "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
        "Jul", "Agu", "Sep", "Okt", "Nov", "Des"
    )

    fun getMonthYearGroup(dateString: String?, dateMillis: Long? = null): MonthYearGroup {
        if (!dateString.isNullOrBlank() && dateString.length >= 7) {
            val parts = dateString.split("-")
            if (parts.size >= 2) {
                val year = parts[0].toIntOrNull()
                val month = parts[1].toIntOrNull()
                if (year != null && month != null && month in 1..12) {
                    val key = String.format(Locale.getDefault(), "%04d-%02d", year, month)
                    val title = "${MONTH_NAMES_UPPER[month - 1]} $year"
                    return MonthYearGroup(key = key, displayTitle = title)
                }
            }
        }

        if (dateMillis != null && dateMillis > 0L) {
            try {
                val cal = Calendar.getInstance()
                cal.timeInMillis = dateMillis
                val year = cal.get(Calendar.YEAR)
                val month = cal.get(Calendar.MONTH) + 1
                val key = String.format(Locale.getDefault(), "%04d-%02d", year, month)
                val title = "${MONTH_NAMES_UPPER[month - 1]} $year"
                return MonthYearGroup(key = key, displayTitle = title)
            } catch (e: Exception) {
                // fallback
            }
        }

        return MonthYearGroup(key = "0000-00", displayTitle = "LAINNYA")
    }

    fun formatDayMonth(dateString: String?, dateMillis: Long? = null): String {
        if (!dateString.isNullOrBlank()) {
            val parts = dateString.split("-")
            if (parts.size >= 3) {
                val day = parts[2].toIntOrNull()
                val month = parts[1].toIntOrNull()
                if (day != null && month != null && month in 1..12) {
                    return "$day ${MONTH_SHORT[month - 1]}"
                }
            }
        }

        if (dateMillis != null && dateMillis > 0L) {
            try {
                val cal = Calendar.getInstance()
                cal.timeInMillis = dateMillis
                val day = cal.get(Calendar.DAY_OF_MONTH)
                val month = cal.get(Calendar.MONTH) + 1
                return "$day ${MONTH_SHORT[month - 1]}"
            } catch (e: Exception) {
                // fallback
            }
        }

        return dateString ?: ""
    }

    fun getWeekKey(date: Date = Date()): String {
        val cal = Calendar.getInstance(Locale.getDefault())
        cal.time = date
        val year = cal.get(Calendar.YEAR)
        val week = cal.get(Calendar.WEEK_OF_YEAR)
        return String.format(Locale.getDefault(), "%04d-W%02d", year, week)
    }

    fun getCurrentWeekDisplay(date: Date = Date()): String {
        return try {
            val cal = Calendar.getInstance(Locale.getDefault())
            cal.time = date
            val week = cal.get(Calendar.WEEK_OF_YEAR)

            val startCal = cal.clone() as Calendar
            startCal.firstDayOfWeek = Calendar.MONDAY
            startCal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)

            val endCal = startCal.clone() as Calendar
            endCal.add(Calendar.DAY_OF_WEEK, 6)

            val startDay = startCal.get(Calendar.DAY_OF_MONTH)
            val startMonth = MONTH_SHORT[startCal.get(Calendar.MONTH)]
            val endDay = endCal.get(Calendar.DAY_OF_MONTH)
            val endMonth = MONTH_SHORT[endCal.get(Calendar.MONTH)]

            if (startMonth == endMonth) {
                "Minggu ke-$week ($startDay - $endDay $startMonth)"
            } else {
                "Minggu ke-$week ($startDay $startMonth - $endDay $endMonth)"
            }
        } catch (e: Exception) {
            "Minggu Berjalan"
        }
    }

    fun getWeekKeyFromDateString(dateStr: String): String {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = sdf.parse(dateStr) ?: return ""
            getWeekKey(date)
        } catch (e: Exception) {
            ""
        }
    }

    fun groupTransactionsByMonth(transactions: List<TransactionEntity>): List<MonthTransactionGroup> {
        return transactions
            .sortedWith(
                compareByDescending<TransactionEntity> { it.dateMillis }
                    .thenByDescending { it.id }
            )
            .groupBy { getMonthYearGroup(it.dateString, it.dateMillis) }
            .map { (group, txs) ->
                MonthTransactionGroup(
                    monthYearTitle = group.displayTitle,
                    key = group.key,
                    transactions = txs
                )
            }
            .sortedByDescending { it.key }
    }
}
