package com.example.util

import java.text.NumberFormat
import java.util.Locale

object CurrencyFormat {
    private val localeID = Locale("in", "ID")

    fun formatRupiah(amount: Double, withSymbol: Boolean = true): String {
        val formatter = NumberFormat.getCurrencyInstance(localeID)
        formatter.maximumFractionDigits = 0
        val formatted = formatter.format(amount)
        return if (withSymbol) {
            formatted.replace("Rp", "Rp ").trim()
        } else {
            formatted.replace("Rp", "").trim()
        }
    }

    fun formatRupiahString(digits: String): String {
        val clean = digits.filter { it.isDigit() }
        if (clean.isEmpty() || clean == "0") return "Rp 0"
        val num = clean.toDoubleOrNull() ?: 0.0
        return formatRupiah(num)
    }
}
