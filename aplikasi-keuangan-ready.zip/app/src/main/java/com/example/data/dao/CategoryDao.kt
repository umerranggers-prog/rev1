package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.CategoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories WHERE isArchived = 0 ORDER BY sortOrder ASC, id ASC")
    fun getAllActiveCategories(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM categories WHERE systemType = :systemType AND transactionType = :transactionType AND isArchived = 0 ORDER BY sortOrder ASC, id ASC")
    fun getCategories(systemType: String, transactionType: String): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM categories WHERE systemType = :systemType AND transactionType = :transactionType AND isArchived = 0 ORDER BY sortOrder ASC, id ASC")
    suspend fun getCategoriesList(systemType: String, transactionType: String): List<CategoryEntity>

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun getCategoryCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: CategoryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategories(categories: List<CategoryEntity>)

    @Update
    suspend fun updateCategory(category: CategoryEntity)

    @Query("UPDATE categories SET isArchived = 1 WHERE id = :id")
    suspend fun archiveCategory(id: Long)

    @Query("DELETE FROM categories WHERE id = :id AND isDefault = 0")
    suspend fun deleteCategoryIfCustom(id: Long)

    @Query("DELETE FROM categories")
    suspend fun deleteAll()
}
