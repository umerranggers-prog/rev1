package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.FinancialSettingsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SettingsDao {
    @Query("SELECT * FROM financial_settings WHERE id = 1")
    fun getSettingsFlow(): Flow<FinancialSettingsEntity?>

    @Query("SELECT * FROM financial_settings WHERE id = 1")
    suspend fun getSettings(): FinancialSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSettings(settings: FinancialSettingsEntity)

    @Update
    suspend fun updateSettings(settings: FinancialSettingsEntity)

    @Query("UPDATE financial_settings SET lastJajanProcessedDate = :dateStr WHERE id = 1")
    suspend fun updateLastJajanDate(dateStr: String)

    @Query("UPDATE financial_settings SET lastJajanProcessedWeek = :weekStr WHERE id = 1")
    suspend fun updateLastJajanWeek(weekStr: String)

    @Query("DELETE FROM financial_settings")
    suspend fun deleteAll()
}
