package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class SystemType {
    PRIBADI,
    USAHA
}

enum class TransactionType {
    PEMASUKAN,
    PENGELUARAN,
    TRANSFER,
    PINJAMAN,
    PENGEMBALIAN,
    PENGEMBALIAN_TALANGAN
}

enum class PersonalPot(val displayName: String) {
    KEBUTUHAN("Kebutuhan (50%)"),
    TABUNGAN("Tabungan (20%)"),
    BEBAS("Bebas (20%)"),
    DANA_DARURAT("Dana Darurat (10%)"),
    JAJAN("Uang Jajan");

    companion object {
        fun fromName(name: String?): PersonalPot = entries.find { it.name == name } ?: KEBUTUHAN
    }
}

enum class BusinessPot(val displayName: String) {
    MODAL_USAHA("Modal Usaha (30%)"),
    DANA_CADANGAN("Dana Cadangan (20%)"),
    SEDEKAH_ZAKAT("Sedekah/Zakat (10%)");

    companion object {
        fun fromName(name: String?): BusinessPot = entries.find { it.name == name } ?: MODAL_USAHA
    }
}

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val systemType: String, // PRIBADI or USAHA
    val transactionType: String, // PEMASUKAN or PENGELUARAN
    val iconName: String = "Category",
    val isDefault: Boolean = false,
    val isArchived: Boolean = false,
    val sortOrder: Int = 0
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val systemType: String, // PRIBADI or USAHA
    val transactionType: String, // PEMASUKAN, PENGELUARAN, TRANSFER, PINJAMAN, PENGEMBALIAN, PENGEMBALIAN_TALANGAN
    val amount: Double,
    val categoryName: String,
    val dateMillis: Long,
    val dateString: String, // YYYY-MM-DD
    val timeString: String, // HH:mm
    val note: String = "",
    val sourcePot: String = "", // e.g. "KEBUTUHAN", "USAHA", etc.
    val targetPot: String? = null, // for transfer/split target
    val parentTransactionId: Long? = null,
    val isAutoSplit: Boolean = false,
    val talanganAmount: Double = 0.0,
    val talanganPot: String = "KEBUTUHAN",
    val profitAmount: Double = 0.0,
    val projectId: Long? = null,
    val projectTitle: String? = null,
    val sourceCategoryName: String? = null,
    val originSystemType: String? = null,
    val originalGrossAmount: Double = 0.0,
    val originalProfitAmount: Double = 0.0,
    val pribadiShareAmount: Double = 0.0,
    val isTalangan: Boolean = false,
    val isTalanganReimbursement: Boolean = false
)

@Entity(tableName = "service_projects")
data class ServiceProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String, // e.g. "Service Mejikom Budi", "Ganti LCD HP Andi", "Panen Cabai"
    val customerName: String = "",
    val categoryName: String = "Jasa Service", // e.g. "Jasa Service", "Pertanian", "Sampingan", "Penjualan"
    val targetAmount: Double = 0.0,
    val estimatedPrice: Double = 0.0,
    val talanganAmount: Double = 0.0,
    val talanganSourcePot: String = "KEBUTUHAN",
    val isCompleted: Boolean = false,
    val status: String = "BERJALAN", // "BERJALAN", "SELESAI", "DIBATALKAN"
    val dateCreatedMillis: Long = 0L,
    val dateCreatedString: String = "",
    val dateCompletedString: String = "",
    val finalPrice: Double = 0.0,
    val profitAmount: Double = 0.0,
    val note: String = ""
)

data class ProjectItemSummary(
    val project: ServiceProjectEntity,
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val totalTalangan: Double = 0.0,
    val repaidTalangan: Double = 0.0,
    val activeTalangan: Double = 0.0,
    val laba: Double = 0.0
)

@Entity(tableName = "loans")
data class LoanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val borrowerName: String,
    val amount: Double,
    val paidAmount: Double = 0.0,
    val dateMillis: Long,
    val dateString: String, // YYYY-MM-DD
    val dueDateString: String = "", // YYYY-MM-DD (optional)
    val note: String = "",
    val systemType: String, // PRIBADI or USAHA
    val sourcePot: String = "", // e.g. "KEBUTUHAN", "MODAL_USAHA", etc.
    val status: String = "BELUM_LUNAS" // "BELUM_LUNAS", "SEBAGIAN", "LUNAS"
)

@Entity(tableName = "loan_repayments")
data class LoanRepaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val loanId: Long,
    val amount: Double,
    val dateMillis: Long,
    val dateString: String, // YYYY-MM-DD
    val timeString: String, // HH:mm
    val note: String = "",
    val targetPot: String = "" // e.g. "KEBUTUHAN", "MODAL_USAHA"
)

@Entity(tableName = "financial_settings")
data class FinancialSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val pribadiKebutuhanPct: Double = 50.0,
    val pribadiTabunganPct: Double = 20.0,
    val pribadiBebasPct: Double = 20.0,
    val pribadiDanaDaruratPct: Double = 10.0,
    val usahaPribadiPct: Double = 40.0,
    val usahaModalPct: Double = 30.0,
    val usahaCadanganPct: Double = 20.0,
    val usahaSedekahPct: Double = 10.0,
    val dailyJajanAmount: Double = 7000.0,
    val weeklyJajanAmount: Double = 49000.0,
    val emergencyFundTarget: Double = 30000000.0,
    val lastJajanProcessedDate: String = "", // YYYY-MM-DD
    val lastJajanProcessedWeek: String = "", // YYYY-Www
    val themeMode: String = "SYSTEM", // "SYSTEM", "LIGHT", "DARK"
    val enableDueNotification: Boolean = true
)

data class FinanceSummary(
    val totalSaldoPribadi: Double = 0.0,
    val kebutuhanBalance: Double = 0.0,
    val tabunganBalance: Double = 0.0,
    val bebasBalance: Double = 0.0,
    val danaDaruratBalance: Double = 0.0,
    val jajanBalance: Double = 0.0,
    val totalPemasukanPribadi: Double = 0.0,
    val totalPengeluaranPribadi: Double = 0.0,
    val terpakaiJajanHariIni: Double = 0.0,

    val totalSaldoUsaha: Double = 0.0,
    val modalUsahaBalance: Double = 0.0,
    val cadanganUsahaBalance: Double = 0.0,
    val sedekahUsahaBalance: Double = 0.0,
    val totalPemasukanUsaha: Double = 0.0,
    val totalPengeluaranUsaha: Double = 0.0,
    val totalBiayaUsaha: Double = 0.0,
    val totalBiayaTalangan: Double = 0.0,
    val labaUsaha: Double = 0.0,

    val totalPiutangPribadi: Double = 0.0,
    val totalPiutangUsaha: Double = 0.0,
    val totalPiutang: Double = 0.0,
    val unpaidLoansCount: Int = 0,
    val overdueLoansCount: Int = 0,
    val totalLendedOut: Double = 0.0,
    val totalRepaidIn: Double = 0.0,

    val activeTalanganCount: Int = 0,
    val totalActiveTalangan: Double = 0.0,
    val projectSummaries: List<ProjectItemSummary> = emptyList()
)

data class BackupData(
    val version: Int = 4,
    val categories: List<CategoryEntity>,
    val transactions: List<TransactionEntity>,
    val settings: FinancialSettingsEntity,
    val loans: List<LoanEntity> = emptyList(),
    val loanRepayments: List<LoanRepaymentEntity> = emptyList(),
    val serviceProjects: List<ServiceProjectEntity> = emptyList()
)
