package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ServiceProjectEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ServiceProjectDao {
    @Query("SELECT * FROM service_projects ORDER BY dateCreatedMillis DESC")
    fun getAllProjects(): Flow<List<ServiceProjectEntity>>

    @Query("SELECT * FROM service_projects WHERE isCompleted = 0 ORDER BY dateCreatedMillis DESC")
    fun getActiveProjectsFlow(): Flow<List<ServiceProjectEntity>>

    @Query("SELECT * FROM service_projects WHERE isCompleted = 0")
    suspend fun getActiveProjectsList(): List<ServiceProjectEntity>

    @Query("SELECT * FROM service_projects ORDER BY dateCreatedMillis DESC")
    suspend fun getAllProjectsList(): List<ServiceProjectEntity>

    @Query("SELECT * FROM service_projects WHERE id = :id")
    suspend fun getProjectById(id: Long): ServiceProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ServiceProjectEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProjects(projects: List<ServiceProjectEntity>)

    @Update
    suspend fun updateProject(project: ServiceProjectEntity)

    @Delete
    suspend fun deleteProject(project: ServiceProjectEntity)

    @Query("DELETE FROM service_projects WHERE id = :id")
    suspend fun deleteProjectById(id: Long)

    @Query("DELETE FROM service_projects")
    suspend fun deleteAll()
}
