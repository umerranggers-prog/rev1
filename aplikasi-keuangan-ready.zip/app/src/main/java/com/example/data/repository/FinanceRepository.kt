package com.example.data.repository

import android.content.Context
import com.example.data.database.AppDatabase
import com.example.data.model.BackupData
import com.example.data.model.CategoryEntity
import com.example.data.model.FinancialSettingsEntity
import com.example.data.model.FinanceSummary
import com.example.data.model.LoanEntity
import com.example.data.model.LoanRepaymentEntity
import com.example.data.model.ServiceProjectEntity
import com.example.data.model.TransactionEntity
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToLong

class FinanceRepository(context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val categoryDao = db.categoryDao()
    private val transactionDao = db.transactionDao()
    private val settingsDao = db.settingsDao()
    private val loanDao = db.loanDao()
    private val serviceProjectDao = db.serviceProjectDao()

    val settingsFlow: Flow<FinancialSettingsEntity?> = settingsDao.getSettingsFlow()
    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    val activeCategories: Flow<List<CategoryEntity>> = categoryDao.getAllActiveCategories()
    val allLoansFlow: Flow<List<LoanEntity>> = loanDao.getAllLoans()
    val activeProjectsFlow: Flow<List<ServiceProjectEntity>> = serviceProjectDao.getActiveProjectsFlow()
    val allProjectsFlow: Flow<List<ServiceProjectEntity>> = serviceProjectDao.getAllProjects()

    fun getRepaymentsFlow(loanId: Long): Flow<List<LoanRepaymentEntity>> {
        return loanDao.getRepaymentsForLoan(loanId)
    }

    suspend fun initializeDefaultsIfNeeded() {
        if (categoryDao.getCategoryCount() == 0) {
            val defaultCategories = listOf(
                // Pribadi Pemasukan
                CategoryEntity(name = "Gaji", systemType = "PRIBADI", transactionType = "PEMASUKAN", iconName = "Work", isDefault = true, sortOrder = 1),
                CategoryEntity(name = "Uang dari Usaha", systemType = "PRIBADI", transactionType = "PEMASUKAN", iconName = "Store", isDefault = true, sortOrder = 2),
                CategoryEntity(name = "Jasa Servis", systemType = "PRIBADI", transactionType = "PEMASUKAN", iconName = "Build", isDefault = true, sortOrder = 3),
                CategoryEntity(name = "Bonus", systemType = "PRIBADI", transactionType = "PEMASUKAN", iconName = "CardGiftcard", isDefault = true, sortOrder = 4),
                CategoryEntity(name = "Freelance", systemType = "PRIBADI", transactionType = "PEMASUKAN", iconName = "Computer", isDefault = true, sortOrder = 5),
                CategoryEntity(name = "Pendapatan Lainnya", systemType = "PRIBADI", transactionType = "PEMASUKAN", iconName = "AttachMoney", isDefault = true, sortOrder = 6),

                // Pribadi Pengeluaran
                CategoryEntity(name = "Makan", systemType = "PRIBADI", transactionType = "PENGELUARAN", iconName = "Restaurant", isDefault = true, sortOrder = 1),
                CategoryEntity(name = "Jajan", systemType = "PRIBADI", transactionType = "PENGELUARAN", iconName = "Fastfood", isDefault = true, sortOrder = 2),
                CategoryEntity(name = "BBM", systemType = "PRIBADI", transactionType = "PENGELUARAN", iconName = "LocalGasStation", isDefault = true, sortOrder = 3),
                CategoryEntity(name = "Perawatan Motor", systemType = "PRIBADI", transactionType = "PENGELUARAN", iconName = "TwoWheeler", isDefault = true, sortOrder = 4),
                CategoryEntity(name = "Pacaran", systemType = "PRIBADI", transactionType = "PENGELUARAN", iconName = "Favorite", isDefault = true, sortOrder = 5),
                CategoryEntity(name = "Hobi", systemType = "PRIBADI", transactionType = "PENGELUARAN", iconName = "SportsEsports", isDefault = true, sortOrder = 6),
                CategoryEntity(name = "Orang Tua", systemType = "PRIBADI", transactionType = "PENGELUARAN", iconName = "FamilyRestroom", isDefault = true, sortOrder = 7),
                CategoryEntity(name = "Sedekah", systemType = "PRIBADI", transactionType = "PENGELUARAN", iconName = "VolunteerActivism", isDefault = true, sortOrder = 8),
                CategoryEntity(name = "Tagihan", systemType = "PRIBADI", transactionType = "PENGELUARAN", iconName = "ReceiptLong", isDefault = true, sortOrder = 9),
                CategoryEntity(name = "Belanja", systemType = "PRIBADI", transactionType = "PENGELUARAN", iconName = "ShoppingBag", isDefault = true, sortOrder = 10),
                CategoryEntity(name = "Lainnya", systemType = "PRIBADI", transactionType = "PENGELUARAN", iconName = "MoreHoriz", isDefault = true, sortOrder = 11),

                // Pribadi Pinjaman & Pengembalian
                CategoryEntity(name = "Uang Dipinjamkan", systemType = "PRIBADI", transactionType = "PINJAMAN", iconName = "Handshake", isDefault = true, sortOrder = 12),
                CategoryEntity(name = "Uang Dikembalikan", systemType = "PRIBADI", transactionType = "PENGEMBALIAN", iconName = "Payments", isDefault = true, sortOrder = 13),

                // Usaha Pemasukan
                CategoryEntity(name = "Penjualan Hasil Panen", systemType = "USAHA", transactionType = "PEMASUKAN", iconName = "Agriculture", isDefault = true, sortOrder = 1),
                CategoryEntity(name = "Penjualan Cabai", systemType = "USAHA", transactionType = "PEMASUKAN", iconName = "Agriculture", isDefault = true, sortOrder = 2),
                CategoryEntity(name = "Penjualan Kacang", systemType = "USAHA", transactionType = "PEMASUKAN", iconName = "Grass", isDefault = true, sortOrder = 3),
                CategoryEntity(name = "Penjualan Barang", systemType = "USAHA", transactionType = "PEMASUKAN", iconName = "Inventory2", isDefault = true, sortOrder = 4),
                CategoryEntity(name = "Jasa Servis", systemType = "USAHA", transactionType = "PEMASUKAN", iconName = "Build", isDefault = true, sortOrder = 5),
                CategoryEntity(name = "Pendapatan Usaha Lainnya", systemType = "USAHA", transactionType = "PEMASUKAN", iconName = "Storefront", isDefault = true, sortOrder = 6),

                // Usaha Pengeluaran
                CategoryEntity(name = "Bibit", systemType = "USAHA", transactionType = "PENGELUARAN", iconName = "Spa", isDefault = true, sortOrder = 1),
                CategoryEntity(name = "Pupuk", systemType = "USAHA", transactionType = "PENGELUARAN", iconName = "Compost", isDefault = true, sortOrder = 2),
                CategoryEntity(name = "Pestisida", systemType = "USAHA", transactionType = "PENGELUARAN", iconName = "PestControl", isDefault = true, sortOrder = 3),
                CategoryEntity(name = "Tenaga Kerja", systemType = "USAHA", transactionType = "PENGELUARAN", iconName = "Groups", isDefault = true, sortOrder = 4),
                CategoryEntity(name = "BBM Usaha", systemType = "USAHA", transactionType = "PENGELUARAN", iconName = "LocalGasStation", isDefault = true, sortOrder = 5),
                CategoryEntity(name = "Peralatan / Sparepart", systemType = "USAHA", transactionType = "PENGELUARAN", iconName = "PrecisionManufacturing", isDefault = true, sortOrder = 6),
                CategoryEntity(name = "Sewa Lahan", systemType = "USAHA", transactionType = "PENGELUARAN", iconName = "Landscape", isDefault = true, sortOrder = 7),
                CategoryEntity(name = "Transportasi", systemType = "USAHA", transactionType = "PENGELUARAN", iconName = "LocalShipping", isDefault = true, sortOrder = 8),
                CategoryEntity(name = "Lainnya Usaha", systemType = "USAHA", transactionType = "PENGELUARAN", iconName = "MoreHoriz", isDefault = true, sortOrder = 9),

                // Usaha Pinjaman & Pengembalian
                CategoryEntity(name = "Uang Dipinjamkan", systemType = "USAHA", transactionType = "PINJAMAN", iconName = "Handshake", isDefault = true, sortOrder = 10),
                CategoryEntity(name = "Uang Dikembalikan", systemType = "USAHA", transactionType = "PENGEMBALIAN", iconName = "Payments", isDefault = true, sortOrder = 11)
            )
            categoryDao.insertCategories(defaultCategories)
        }

        if (settingsDao.getSettings() == null) {
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val initialSettings = FinancialSettingsEntity(lastJajanProcessedDate = todayStr)
            settingsDao.insertOrUpdateSettings(initialSettings)
        }

        processWeeklyJajanIfNeeded()
    }

    suspend fun processWeeklyJajanIfNeeded() {
        val settings = settingsDao.getSettings() ?: return
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val todayStr = dateFormat.format(Date())
        val currentWeekKey = com.example.util.DateUtils.getWeekKey()

        if (settings.lastJajanProcessedWeek == currentWeekKey) {
            return
        }

        try {
            val allTx = transactionDao.getAllTransactionsList()
            // Check if an allocation for this week was already recorded to prevent duplicate allocation
            val alreadyAllocated = allTx.any {
                it.systemType == "PRIBADI" &&
                it.targetPot == "JAJAN" &&
                it.transactionType == "TRANSFER" &&
                (it.note.contains(currentWeekKey) || (it.categoryName.contains("Uang Jajan") && it.dateString.isNotEmpty() && com.example.util.DateUtils.getWeekKeyFromDateString(it.dateString) == currentWeekKey))
            }
            if (alreadyAllocated) {
                settingsDao.updateLastJajanWeek(currentWeekKey)
                return
            }

            // Calculate current available balance in KEBUTUHAN pot
            val kebPct = settings.pribadiKebutuhanPct / 100.0
            var currentKebutuhanBalance = 0.0

            for (tx in allTx) {
                when (tx.transactionType) {
                    "PEMASUKAN" -> {
                        if (tx.systemType == "PRIBADI" && !tx.isAutoSplit && tx.originSystemType != "USAHA") {
                            currentKebutuhanBalance += (tx.amount * kebPct)
                        }
                    }
                    "PENGELUARAN" -> {
                        if (tx.sourcePot == "KEBUTUHAN") currentKebutuhanBalance -= tx.amount
                    }
                    "TRANSFER" -> {
                        if (!(tx.isAutoSplit && tx.sourcePot == "PRIBADI")) {
                            if (tx.sourcePot == "KEBUTUHAN") currentKebutuhanBalance -= tx.amount
                            if (tx.targetPot == "KEBUTUHAN") currentKebutuhanBalance += tx.amount
                        }
                    }
                    "PINJAMAN" -> {
                        if (tx.sourcePot == "KEBUTUHAN") currentKebutuhanBalance -= tx.amount
                    }
                    "PENGEMBALIAN", "PENGEMBALIAN_TALANGAN" -> {
                        if (tx.targetPot == "KEBUTUHAN") currentKebutuhanBalance += tx.amount
                    }
                }
            }

            // Uang jajan diambil dari saldo Kebutuhan. Jika saldo nol atau kurang, jangan buat alokasi
            if (currentKebutuhanBalance <= 0.0) {
                return
            }

            val weeklyAmount = if (settings.weeklyJajanAmount > 0) settings.weeklyJajanAmount else 49000.0
            val actualAllocation = minOf(weeklyAmount, currentKebutuhanBalance)

            if (actualAllocation > 0.0) {
                val nowMillis = System.currentTimeMillis()
                val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(nowMillis))

                val jajanAllocTx = TransactionEntity(
                    systemType = "PRIBADI",
                    transactionType = "TRANSFER",
                    amount = actualAllocation,
                    categoryName = "Alokasi Uang Jajan",
                    dateMillis = nowMillis,
                    dateString = todayStr,
                    timeString = timeStr,
                    note = "Alokasi Uang Jajan Mingguan ($currentWeekKey)",
                    sourcePot = "KEBUTUHAN",
                    targetPot = "JAJAN",
                    isAutoSplit = false // Visible in history with date & nominal
                )
                transactionDao.insertTransaction(jajanAllocTx)
                settingsDao.updateLastJajanWeek(currentWeekKey)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun addTransaction(
        systemType: String,
        transactionType: String,
        amount: Double,
        categoryName: String,
        dateMillis: Long,
        dateString: String,
        timeString: String,
        note: String,
        sourcePot: String,
        targetPot: String?,
        talanganAmount: Double = 0.0,
        talanganPot: String = "KEBUTUHAN",
        projectId: Long? = null,
        projectTitle: String? = null,
        isTalangan: Boolean = false
    ) {
        val settings = settingsDao.getSettings() ?: FinancialSettingsEntity()

        if (systemType == "PRIBADI" && transactionType == "PEMASUKAN") {
            val kebPct = settings.pribadiKebutuhanPct / 100.0
            val tabPct = settings.pribadiTabunganPct / 100.0
            val bebPct = settings.pribadiBebasPct / 100.0

            val kebAmt = (amount * kebPct).roundToLong().toDouble()
            val tabAmt = (amount * tabPct).roundToLong().toDouble()
            val bebAmt = (amount * bebPct).roundToLong().toDouble()
            val darAmt = amount - (kebAmt + tabAmt + bebAmt)

            val parentTx = TransactionEntity(
                systemType = "PRIBADI",
                transactionType = "PEMASUKAN",
                amount = amount,
                categoryName = categoryName,
                dateMillis = dateMillis,
                dateString = dateString,
                timeString = timeString,
                note = note,
                sourcePot = "PRIBADI",
                targetPot = null,
                isAutoSplit = false
            )
            val parentId = transactionDao.insertTransaction(parentTx)

            val splitEntries = listOf(
                TransactionEntity(systemType = "PRIBADI", transactionType = "TRANSFER", amount = kebAmt, categoryName = "Kebutuhan", dateMillis = dateMillis, dateString = dateString, timeString = timeString, note = "Pemasukan Pribadi (${settings.pribadiKebutuhanPct.toInt()}% Kebutuhan)", sourcePot = "PRIBADI", targetPot = "KEBUTUHAN", parentTransactionId = parentId, isAutoSplit = true),
                TransactionEntity(systemType = "PRIBADI", transactionType = "TRANSFER", amount = tabAmt, categoryName = "Tabungan", dateMillis = dateMillis, dateString = dateString, timeString = timeString, note = "Pemasukan Pribadi (${settings.pribadiTabunganPct.toInt()}% Tabungan)", sourcePot = "PRIBADI", targetPot = "TABUNGAN", parentTransactionId = parentId, isAutoSplit = true),
                TransactionEntity(systemType = "PRIBADI", transactionType = "TRANSFER", amount = bebAmt, categoryName = "Bebas", dateMillis = dateMillis, dateString = dateString, timeString = timeString, note = "Pemasukan Pribadi (${settings.pribadiBebasPct.toInt()}% Bebas)", sourcePot = "PRIBADI", targetPot = "BEBAS", parentTransactionId = parentId, isAutoSplit = true),
                TransactionEntity(systemType = "PRIBADI", transactionType = "TRANSFER", amount = darAmt, categoryName = "Dana Darurat", dateMillis = dateMillis, dateString = dateString, timeString = timeString, note = "Pemasukan Pribadi (${settings.pribadiDanaDaruratPct.toInt()}% Dana Darurat)", sourcePot = "PRIBADI", targetPot = "DANA_DARURAT", parentTransactionId = parentId, isAutoSplit = true)
            )
            transactionDao.insertTransactions(splitEntries)

        } else if (systemType == "USAHA" && transactionType == "PEMASUKAN") {
            // Find resolved project info if available
            val proj = if (projectId != null) serviceProjectDao.getProjectById(projectId) else null
            val resolvedTitle = projectTitle ?: proj?.title

            // Calculate active talangan for this project
            var activeTalanganForProject = 0.0
            var resolvedTalanganPot = talanganPot
            if (projectId != null) {
                val allTx = transactionDao.getAllTransactionsList()
                val projExpenses = allTx.filter { it.projectId == projectId && it.transactionType == "PENGELUARAN" }
                val projTalanganSum = projExpenses.filter { it.isTalangan || it.sourcePot in listOf("KEBUTUHAN", "BEBAS", "TABUNGAN", "DANA_DARURAT", "JAJAN") }.sumOf { it.amount } + (proj?.talanganAmount ?: 0.0)
                val projRepaidSum = allTx.filter { it.projectId == projectId && (it.transactionType == "PENGELUARAN" || it.transactionType == "PENGEMBALIAN_TALANGAN" || it.isTalanganReimbursement) && it.isTalanganReimbursement }.sumOf { it.amount } + allTx.filter { it.projectId == projectId && it.talanganAmount > 0 && !it.isAutoSplit }.sumOf { it.talanganAmount }
                activeTalanganForProject = (projTalanganSum - projRepaidSum).coerceAtLeast(0.0)

                val firstTalanganTx = projExpenses.firstOrNull { it.isTalangan || it.sourcePot in listOf("KEBUTUHAN", "BEBAS", "TABUNGAN", "DANA_DARURAT", "JAJAN") }
                if (firstTalanganTx != null && firstTalanganTx.sourcePot.isNotEmpty()) {
                    resolvedTalanganPot = firstTalanganTx.sourcePot
                } else if (proj?.talanganSourcePot?.isNotEmpty() == true) {
                    resolvedTalanganPot = proj.talanganSourcePot
                }
            } else if (talanganAmount > 0) {
                activeTalanganForProject = talanganAmount
            }

            val effectiveTalangan = if (activeTalanganForProject > 0) activeTalanganForProject.coerceAtMost(amount) else 0.0
            val profitAmount = (amount - effectiveTalangan).coerceAtLeast(0.0)

            val parentTx = TransactionEntity(
                systemType = "USAHA",
                transactionType = "PEMASUKAN",
                amount = amount,
                categoryName = categoryName,
                dateMillis = dateMillis,
                dateString = dateString,
                timeString = timeString,
                note = note,
                sourcePot = "USAHA",
                targetPot = null,
                isAutoSplit = false,
                talanganAmount = effectiveTalangan,
                talanganPot = resolvedTalanganPot,
                profitAmount = profitAmount,
                projectId = projectId,
                projectTitle = resolvedTitle,
                sourceCategoryName = categoryName,
                originSystemType = "USAHA",
                originalGrossAmount = amount,
                originalProfitAmount = profitAmount,
                pribadiShareAmount = if (profitAmount > 0) (profitAmount * (settings.usahaPribadiPct / 100.0)).roundToLong().toDouble() else 0.0
            )
            val parentId = transactionDao.insertTransaction(parentTx)

            // 1. Return talangan amount directly to the personal pot used WITHOUT 50/20/20/10 split
            if (effectiveTalangan > 0) {
                val talanganReimburseTx = TransactionEntity(
                    systemType = "PRIBADI",
                    transactionType = "PENGEMBALIAN_TALANGAN",
                    amount = effectiveTalangan,
                    categoryName = "Pengembalian Talangan",
                    dateMillis = dateMillis,
                    dateString = dateString,
                    timeString = timeString,
                    note = "Pengembalian modal talangan${if (!resolvedTitle.isNullOrBlank()) " • Project: $resolvedTitle" else ""}",
                    sourcePot = "USAHA",
                    targetPot = resolvedTalanganPot,
                    parentTransactionId = parentId,
                    projectId = projectId,
                    projectTitle = resolvedTitle,
                    sourceCategoryName = categoryName,
                    originSystemType = "USAHA",
                    originalGrossAmount = amount,
                    originalProfitAmount = profitAmount,
                    isTalanganReimbursement = true,
                    isAutoSplit = false
                )
                transactionDao.insertTransaction(talanganReimburseTx)
            }

            // 2. Profit amount is split according to business percentages
            if (profitAmount > 0) {
                val pribPct = settings.usahaPribadiPct / 100.0
                val modPct = settings.usahaModalPct / 100.0
                val cadPct = settings.usahaCadanganPct / 100.0

                val pribAmt = (profitAmount * pribPct).roundToLong().toDouble()
                val modAmt = (profitAmount * modPct).roundToLong().toDouble()
                val cadAmt = (profitAmount * cadPct).roundToLong().toDouble()
                val sedAmt = profitAmount - (pribAmt + modAmt + cadAmt)

                val bizSplits = listOf(
                    TransactionEntity(systemType = "USAHA", transactionType = "TRANSFER", amount = modAmt, categoryName = "Modal Usaha", dateMillis = dateMillis, dateString = dateString, timeString = timeString, note = "Laba Usaha (${settings.usahaModalPct.toInt()}% Modal)", sourcePot = "USAHA", targetPot = "MODAL_USAHA", parentTransactionId = parentId, isAutoSplit = true, projectId = projectId, projectTitle = resolvedTitle, sourceCategoryName = categoryName, originSystemType = "USAHA", originalGrossAmount = amount, originalProfitAmount = profitAmount),
                    TransactionEntity(systemType = "USAHA", transactionType = "TRANSFER", amount = cadAmt, categoryName = "Dana Cadangan", dateMillis = dateMillis, dateString = dateString, timeString = timeString, note = "Laba Usaha (${settings.usahaCadanganPct.toInt()}% Cadangan)", sourcePot = "USAHA", targetPot = "DANA_CADANGAN", parentTransactionId = parentId, isAutoSplit = true, projectId = projectId, projectTitle = resolvedTitle, sourceCategoryName = categoryName, originSystemType = "USAHA", originalGrossAmount = amount, originalProfitAmount = profitAmount),
                    TransactionEntity(systemType = "USAHA", transactionType = "TRANSFER", amount = sedAmt, categoryName = "Sedekah/Zakat", dateMillis = dateMillis, dateString = dateString, timeString = timeString, note = "Laba Usaha (${settings.usahaSedekahPct.toInt()}% Sedekah)", sourcePot = "USAHA", targetPot = "SEDEKAH_ZAKAT", parentTransactionId = parentId, isAutoSplit = true, projectId = projectId, projectTitle = resolvedTitle, sourceCategoryName = categoryName, originSystemType = "USAHA", originalGrossAmount = amount, originalProfitAmount = profitAmount),
                    TransactionEntity(systemType = "USAHA", transactionType = "TRANSFER", amount = pribAmt, categoryName = "Uang ke Pribadi", dateMillis = dateMillis, dateString = dateString, timeString = timeString, note = "Laba Usaha (${settings.usahaPribadiPct.toInt()}% Pribadi)", sourcePot = "USAHA", targetPot = "PRIBADI", parentTransactionId = parentId, isAutoSplit = true, projectId = projectId, projectTitle = resolvedTitle, sourceCategoryName = categoryName, originSystemType = "USAHA", originalGrossAmount = amount, originalProfitAmount = profitAmount, pribadiShareAmount = pribAmt)
                )
                transactionDao.insertTransactions(bizSplits)

                // 3. The personal share from business profit is recorded as personal income with origin from Usaha
                if (pribAmt > 0) {
                    val pribIncomeTx = TransactionEntity(
                        systemType = "PRIBADI",
                        transactionType = "PEMASUKAN",
                        amount = pribAmt,
                        categoryName = categoryName,
                        dateMillis = dateMillis,
                        dateString = dateString,
                        timeString = timeString,
                        note = "${categoryName} — ${com.example.util.CurrencyFormat.formatRupiah(pribAmt)} — ${settings.usahaPribadiPct.toInt()}% dari Usaha${if (!resolvedTitle.isNullOrBlank()) " • Project: $resolvedTitle" else ""}",
                        sourcePot = "USAHA",
                        targetPot = "BEBAS",
                        parentTransactionId = parentId,
                        isAutoSplit = false,
                        projectId = projectId,
                        projectTitle = resolvedTitle,
                        sourceCategoryName = categoryName,
                        originSystemType = "USAHA",
                        originalGrossAmount = amount,
                        originalProfitAmount = profitAmount,
                        pribadiShareAmount = pribAmt
                    )
                    transactionDao.insertTransaction(pribIncomeTx)
                }
            }

        } else if (systemType == "USAHA" && transactionType == "PENGELUARAN") {
            val isPersonalTalangan = isTalangan || sourcePot in listOf("KEBUTUHAN", "BEBAS", "TABUNGAN", "DANA_DARURAT", "JAJAN")
            val proj = if (projectId != null) serviceProjectDao.getProjectById(projectId) else null
            val resolvedTitle = projectTitle ?: proj?.title

            val tx = TransactionEntity(
                systemType = "USAHA",
                transactionType = "PENGELUARAN",
                amount = amount,
                categoryName = categoryName,
                dateMillis = dateMillis,
                dateString = dateString,
                timeString = timeString,
                note = note,
                sourcePot = sourcePot,
                targetPot = targetPot,
                isAutoSplit = false,
                projectId = projectId,
                projectTitle = resolvedTitle,
                isTalangan = isPersonalTalangan,
                talanganPot = if (isPersonalTalangan) sourcePot else "KEBUTUHAN"
            )
            transactionDao.insertTransaction(tx)

        } else {
            val tx = TransactionEntity(
                systemType = systemType,
                transactionType = transactionType,
                amount = amount,
                categoryName = categoryName,
                dateMillis = dateMillis,
                dateString = dateString,
                timeString = timeString,
                note = note,
                sourcePot = sourcePot,
                targetPot = targetPot,
                isAutoSplit = false,
                projectId = projectId,
                projectTitle = projectTitle
            )
            transactionDao.insertTransaction(tx)
        }
    }

    suspend fun repayTalangan(
        projectId: Long,
        repaymentAmount: Double,
        sourceUsahaPot: String = "MODAL_USAHA",
        targetPersonalPot: String = "KEBUTUHAN",
        note: String = ""
    ): Result<Unit> {
        if (repaymentAmount <= 0) return Result.failure(Exception("Nominal harus lebih dari 0"))
        val project = serviceProjectDao.getProjectById(projectId) ?: return Result.failure(Exception("Project tidak ditemukan"))
        val now = System.currentTimeMillis()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val dateStr = dateFormat.format(Date(now))
        val timeStr = timeFormat.format(Date(now))

        val defaultNote = if (note.isNotBlank()) note else "Pengembalian talangan project ${project.title}"

        // 1. Usaha expense from chosen business pot (e.g. MODAL_USAHA)
        val usahaRepayTx = TransactionEntity(
            systemType = "USAHA",
            transactionType = "PENGELUARAN",
            amount = repaymentAmount,
            categoryName = "Pengembalian Talangan",
            dateMillis = now,
            dateString = dateStr,
            timeString = timeStr,
            note = defaultNote,
            sourcePot = sourceUsahaPot,
            targetPot = null,
            projectId = projectId,
            projectTitle = project.title,
            isTalanganReimbursement = true,
            isAutoSplit = false
        )
        val parentId = transactionDao.insertTransaction(usahaRepayTx)

        // 2. Personal refund into chosen personal pot (e.g. KEBUTUHAN)
        val pribadiRefundTx = TransactionEntity(
            systemType = "PRIBADI",
            transactionType = "PENGEMBALIAN_TALANGAN",
            amount = repaymentAmount,
            categoryName = "Pengembalian Talangan",
            dateMillis = now,
            dateString = dateStr,
            timeString = timeStr,
            note = defaultNote,
            sourcePot = sourceUsahaPot,
            targetPot = targetPersonalPot,
            parentTransactionId = parentId,
            projectId = projectId,
            projectTitle = project.title,
            isTalanganReimbursement = true,
            isAutoSplit = false
        )
        transactionDao.insertTransaction(pribadiRefundTx)
        return Result.success(Unit)
    }

    suspend fun addProject(
        title: String,
        customerName: String = "",
        categoryName: String = "Jasa Service",
        targetAmount: Double = 0.0,
        note: String = ""
    ): Long {
        val now = System.currentTimeMillis()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val dateString = dateFormat.format(Date(now))
        val project = ServiceProjectEntity(
            title = title,
            customerName = customerName,
            categoryName = categoryName,
            targetAmount = targetAmount,
            status = "BERJALAN",
            isCompleted = false,
            dateCreatedMillis = now,
            dateCreatedString = dateString,
            note = note
        )
        return serviceProjectDao.insertProject(project)
    }

    suspend fun updateProject(project: ServiceProjectEntity) {
        serviceProjectDao.updateProject(project)
    }

    suspend fun updateProjectStatus(id: Long, status: String) {
        val project = serviceProjectDao.getProjectById(id) ?: return
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val dateCompleted = if (status == "SELESAI") dateFormat.format(Date()) else ""
        val updated = project.copy(
            status = status,
            isCompleted = (status == "SELESAI"),
            dateCompletedString = dateCompleted
        )
        serviceProjectDao.updateProject(updated)
    }

    suspend fun deleteProject(id: Long) {
        serviceProjectDao.deleteProjectById(id)
    }

    suspend fun createServiceTalangan(
        title: String,
        customerName: String,
        estimatedPrice: Double,
        talanganAmount: Double,
        talanganSourcePot: String,
        note: String
    ): Long {
        val now = System.currentTimeMillis()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val dateString = dateFormat.format(Date(now))
        val timeString = timeFormat.format(Date(now))

        val project = ServiceProjectEntity(
            title = title,
            customerName = customerName,
            estimatedPrice = estimatedPrice,
            talanganAmount = talanganAmount,
            talanganSourcePot = talanganSourcePot,
            isCompleted = false,
            status = "BERJALAN",
            dateCreatedMillis = now,
            dateCreatedString = dateString,
            note = note
        )
        val projectId = serviceProjectDao.insertProject(project)

        if (talanganAmount > 0) {
            val tx = TransactionEntity(
                systemType = "USAHA",
                transactionType = "PENGELUARAN",
                amount = talanganAmount,
                categoryName = "Talangan Usaha",
                dateMillis = now,
                dateString = dateString,
                timeString = timeString,
                note = "Talangan $title${if (customerName.isNotEmpty()) " ($customerName)" else ""}",
                sourcePot = talanganSourcePot,
                targetPot = null,
                isAutoSplit = false,
                projectId = projectId,
                projectTitle = title,
                isTalangan = true,
                talanganPot = talanganSourcePot
            )
            transactionDao.insertTransaction(tx)
        }

        return projectId
    }

    suspend fun completeServiceProject(
        projectId: Long,
        finalPrice: Double,
        note: String
    ) {
        val project = serviceProjectDao.getProjectById(projectId) ?: return
        val now = System.currentTimeMillis()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val dateString = dateFormat.format(Date(now))
        val timeString = timeFormat.format(Date(now))

        val updated = project.copy(
            isCompleted = true,
            status = "SELESAI",
            dateCompletedString = dateString,
            finalPrice = finalPrice,
            note = if (note.isNotEmpty()) note else project.note
        )
        serviceProjectDao.updateProject(updated)

        // Process transaction
        addTransaction(
            systemType = "USAHA",
            transactionType = "PEMASUKAN",
            amount = finalPrice,
            categoryName = project.categoryName.ifEmpty { "Jasa Servis" },
            dateMillis = now,
            dateString = dateString,
            timeString = timeString,
            note = "${project.title}${if (project.customerName.isNotEmpty()) " - ${project.customerName}" else ""}",
            sourcePot = "USAHA",
            targetPot = null,
            projectId = projectId,
            projectTitle = project.title
        )
    }

    suspend fun deleteServiceProject(id: Long) {
        serviceProjectDao.deleteProjectById(id)
    }

    suspend fun addLoan(
        borrowerName: String,
        amount: Double,
        dateMillis: Long,
        dateString: String,
        dueDateString: String,
        note: String,
        systemType: String,
        sourcePot: String
    ): Long {
        val loan = LoanEntity(
            borrowerName = borrowerName,
            amount = amount,
            paidAmount = 0.0,
            dateMillis = dateMillis,
            dateString = dateString,
            dueDateString = dueDateString,
            note = note,
            systemType = systemType,
            sourcePot = sourcePot,
            status = "BELUM_LUNAS"
        )
        val loanId = loanDao.insertLoan(loan)

        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(dateMillis))
        val tx = TransactionEntity(
            systemType = systemType,
            transactionType = "PINJAMAN",
            amount = amount,
            categoryName = "Uang Dipinjamkan",
            dateMillis = dateMillis,
            dateString = dateString,
            timeString = timeStr,
            note = "Pinjamkan ke $borrowerName${if (note.isNotEmpty()) ": $note" else ""}",
            sourcePot = sourcePot,
            targetPot = null,
            isAutoSplit = false
        )
        transactionDao.insertTransaction(tx)
        return loanId
    }

    suspend fun addRepayment(
        loanId: Long,
        repaymentAmount: Double,
        dateMillis: Long,
        dateString: String,
        timeString: String,
        note: String,
        targetPot: String
    ): Result<Unit> {
        val loan = loanDao.getLoanById(loanId) ?: return Result.failure(Exception("Pinjaman tidak ditemukan."))
        val remaining = loan.amount - loan.paidAmount
        if (repaymentAmount > remaining + 0.01) {
            return Result.failure(Exception("Nominal pengembalian melebihi sisa pinjaman."))
        }

        val newPaid = loan.paidAmount + repaymentAmount
        val newStatus = if (newPaid >= loan.amount - 0.01) "LUNAS" else "SEBAGIAN"

        val updatedLoan = loan.copy(
            paidAmount = newPaid,
            status = newStatus
        )
        loanDao.updateLoan(updatedLoan)

        val repayment = LoanRepaymentEntity(
            loanId = loanId,
            amount = repaymentAmount,
            dateMillis = dateMillis,
            dateString = dateString,
            timeString = timeString,
            note = note,
            targetPot = targetPot
        )
        loanDao.insertRepayment(repayment)

        val tx = TransactionEntity(
            systemType = loan.systemType,
            transactionType = "PENGEMBALIAN",
            amount = repaymentAmount,
            categoryName = "Uang Dikembalikan",
            dateMillis = dateMillis,
            dateString = dateString,
            timeString = timeString,
            note = "Pengembalian dari ${loan.borrowerName}${if (note.isNotEmpty()) ": $note" else ""}",
            sourcePot = "",
            targetPot = targetPot,
            isAutoSplit = false
        )
        transactionDao.insertTransaction(tx)

        return Result.success(Unit)
    }

    suspend fun deleteLoan(id: Long) {
        loanDao.deleteLoan(id)
        loanDao.deleteRepaymentsForLoan(id)
    }

    suspend fun deleteTransaction(id: Long) {
        transactionDao.deleteTransaction(id)
    }

    suspend fun updateTransaction(transaction: TransactionEntity) {
        val allTx = transactionDao.getAllTransactionsList()
        val oldTx = allTx.firstOrNull { it.id == transaction.id }
        if (oldTx != null && oldTx.transactionType == "PEMASUKAN" && !oldTx.isAutoSplit && oldTx.systemType == "PRIBADI") {
            val settings = settingsDao.getSettings() ?: FinancialSettingsEntity()
            val kebPct = settings.pribadiKebutuhanPct / 100.0
            val tabPct = settings.pribadiTabunganPct / 100.0
            val bebPct = settings.pribadiBebasPct / 100.0

            val kebAmt = kotlin.math.round(transaction.amount * kebPct)
            val tabAmt = kotlin.math.round(transaction.amount * tabPct)
            val bebAmt = kotlin.math.round(transaction.amount * bebPct)
            val darAmt = transaction.amount - (kebAmt + tabAmt + bebAmt)

            transactionDao.deleteTransaction(transaction.id)
            val parentId = transactionDao.insertTransaction(transaction.copy(id = transaction.id))

            val splitEntries = listOf(
                TransactionEntity(
                    systemType = "PRIBADI",
                    transactionType = "TRANSFER",
                    amount = kebAmt,
                    categoryName = "Kebutuhan",
                    dateMillis = transaction.dateMillis,
                    dateString = transaction.dateString,
                    timeString = transaction.timeString,
                    note = "Pemasukan Pribadi (${settings.pribadiKebutuhanPct.toInt()}% Kebutuhan)",
                    sourcePot = "PRIBADI",
                    targetPot = "KEBUTUHAN",
                    parentTransactionId = parentId,
                    isAutoSplit = true
                ),
                TransactionEntity(
                    systemType = "PRIBADI",
                    transactionType = "TRANSFER",
                    amount = tabAmt,
                    categoryName = "Tabungan",
                    dateMillis = transaction.dateMillis,
                    dateString = transaction.dateString,
                    timeString = transaction.timeString,
                    note = "Pemasukan Pribadi (${settings.pribadiTabunganPct.toInt()}% Tabungan)",
                    sourcePot = "PRIBADI",
                    targetPot = "TABUNGAN",
                    parentTransactionId = parentId,
                    isAutoSplit = true
                ),
                TransactionEntity(
                    systemType = "PRIBADI",
                    transactionType = "TRANSFER",
                    amount = bebAmt,
                    categoryName = "Bebas",
                    dateMillis = transaction.dateMillis,
                    dateString = transaction.dateString,
                    timeString = transaction.timeString,
                    note = "Pemasukan Pribadi (${settings.pribadiBebasPct.toInt()}% Bebas)",
                    sourcePot = "PRIBADI",
                    targetPot = "BEBAS",
                    parentTransactionId = parentId,
                    isAutoSplit = true
                ),
                TransactionEntity(
                    systemType = "PRIBADI",
                    transactionType = "TRANSFER",
                    amount = darAmt,
                    categoryName = "Dana Darurat",
                    dateMillis = transaction.dateMillis,
                    dateString = transaction.dateString,
                    timeString = transaction.timeString,
                    note = "Pemasukan Pribadi (${settings.pribadiDanaDaruratPct.toInt()}% Dana Darurat)",
                    sourcePot = "PRIBADI",
                    targetPot = "DANA_DARURAT",
                    parentTransactionId = parentId,
                    isAutoSplit = true
                )
            )
            transactionDao.insertTransactions(splitEntries)
        } else {
            transactionDao.insertTransaction(transaction)
        }
        processWeeklyJajanIfNeeded()
    }

    suspend fun updateSettings(settings: FinancialSettingsEntity) {
        settingsDao.insertOrUpdateSettings(settings)
    }

    suspend fun addCategory(category: CategoryEntity) {
        categoryDao.insertCategory(category)
    }

    suspend fun updateCategory(category: CategoryEntity) {
        categoryDao.updateCategory(category)
    }

    suspend fun archiveCategory(id: Long) {
        categoryDao.archiveCategory(id)
    }

    fun getCategoriesFlow(systemType: String, transactionType: String): Flow<List<CategoryEntity>> {
        return categoryDao.getCategories(systemType, transactionType)
    }

    val summaryFlow: Flow<FinanceSummary> = combine(
        transactionDao.getAllTransactions(),
        loanDao.getAllLoans(),
        serviceProjectDao.getAllProjects(),
        settingsDao.getSettingsFlow()
    ) { txList, loanList, projectList, settings ->
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val todayStr = dateFormat.format(Date())

        var kebutuhan = 0.0
        var tabungan = 0.0
        var bebas = 0.0
        var danaDarurat = 0.0
        var jajan = 0.0

        var totalPemasukanPribadi = 0.0
        var totalPengeluaranPribadi = 0.0
        var terpakaiJajanHariIni = 0.0

        var modalUsaha = 0.0
        var cadanganUsaha = 0.0
        var sedekahUsaha = 0.0

        var totalPemasukanUsaha = 0.0
        var totalPengeluaranUsaha = 0.0
        var totalBiayaTalangan = 0.0
        var totalLabaCalculated = 0.0

        val kebPct = (settings?.pribadiKebutuhanPct ?: 50.0) / 100.0
        val tabPct = (settings?.pribadiTabunganPct ?: 20.0) / 100.0
        val bebPct = (settings?.pribadiBebasPct ?: 20.0) / 100.0
        val darPct = (settings?.pribadiDanaDaruratPct ?: 10.0) / 100.0

        for (tx in txList) {
            when (tx.transactionType) {
                "PEMASUKAN" -> {
                    if (tx.systemType == "PRIBADI") {
                        totalPemasukanPribadi += tx.amount
                        if (tx.originSystemType == "USAHA") {
                            // 40% from usaha profit goes directly to BEBAS without 50/20/20/10 split
                            bebas += tx.amount
                        } else if (!tx.isAutoSplit) {
                            // Regular personal income: split dynamically with current settings
                            kebutuhan += (tx.amount * kebPct)
                            tabungan += (tx.amount * tabPct)
                            bebas += (tx.amount * bebPct)
                            danaDarurat += (tx.amount * darPct)
                        }
                    } else if (tx.systemType == "USAHA") {
                        totalPemasukanUsaha += tx.amount
                        if (tx.talanganAmount > 0) {
                            totalBiayaTalangan += tx.talanganAmount
                        }
                    }
                }
                "PENGELUARAN" -> {
                    if (tx.systemType == "PRIBADI") {
                        totalPengeluaranPribadi += tx.amount
                        when (tx.sourcePot) {
                            "KEBUTUHAN" -> kebutuhan -= tx.amount
                            "TABUNGAN" -> tabungan -= tx.amount
                            "BEBAS" -> bebas -= tx.amount
                            "DANA_DARURAT" -> danaDarurat -= tx.amount
                            "JAJAN" -> {
                                jajan -= tx.amount
                                if (tx.dateString == todayStr) {
                                    terpakaiJajanHariIni += tx.amount
                                }
                            }
                        }
                    } else if (tx.systemType == "USAHA") {
                        if (!tx.isTalanganReimbursement) {
                            totalPengeluaranUsaha += tx.amount
                        }
                        when (tx.sourcePot) {
                            "MODAL_USAHA" -> modalUsaha -= tx.amount
                            "DANA_CADANGAN" -> cadanganUsaha -= tx.amount
                            "SEDEKAH_ZAKAT" -> sedekahUsaha -= tx.amount
                            // If personal pot was used for talangan:
                            "KEBUTUHAN" -> kebutuhan -= tx.amount
                            "TABUNGAN" -> tabungan -= tx.amount
                            "BEBAS" -> bebas -= tx.amount
                            "DANA_DARURAT" -> danaDarurat -= tx.amount
                            "JAJAN" -> jajan -= tx.amount
                        }
                    }
                }
                "TRANSFER" -> {
                    // Ignore auto-split transfers originating from PRIBADI because regular income is apportioned dynamically above
                    if (!(tx.isAutoSplit && tx.sourcePot == "PRIBADI")) {
                        when (tx.sourcePot) {
                            "KEBUTUHAN" -> kebutuhan -= tx.amount
                            "TABUNGAN" -> tabungan -= tx.amount
                            "BEBAS" -> bebas -= tx.amount
                            "DANA_DARURAT" -> danaDarurat -= tx.amount
                            "JAJAN" -> jajan -= tx.amount
                            "MODAL_USAHA" -> modalUsaha -= tx.amount
                            "DANA_CADANGAN" -> cadanganUsaha -= tx.amount
                            "SEDEKAH_ZAKAT" -> sedekahUsaha -= tx.amount
                        }

                        when (tx.targetPot) {
                            "KEBUTUHAN" -> kebutuhan += tx.amount
                            "TABUNGAN" -> tabungan += tx.amount
                            "BEBAS" -> bebas += tx.amount
                            "DANA_DARURAT" -> danaDarurat += tx.amount
                            "JAJAN" -> jajan += tx.amount
                            "MODAL_USAHA" -> modalUsaha += tx.amount
                            "DANA_CADANGAN" -> cadanganUsaha += tx.amount
                            "SEDEKAH_ZAKAT" -> sedekahUsaha += tx.amount
                        }
                    }
                }
                "PINJAMAN" -> {
                    when (tx.sourcePot) {
                        "KEBUTUHAN" -> kebutuhan -= tx.amount
                        "TABUNGAN" -> tabungan -= tx.amount
                        "BEBAS" -> bebas -= tx.amount
                        "DANA_DARURAT" -> danaDarurat -= tx.amount
                        "JAJAN" -> jajan -= tx.amount
                        "MODAL_USAHA" -> modalUsaha -= tx.amount
                        "DANA_CADANGAN" -> cadanganUsaha -= tx.amount
                        "SEDEKAH_ZAKAT" -> sedekahUsaha -= tx.amount
                    }
                }
                "PENGEMBALIAN" -> {
                    when (tx.targetPot) {
                        "KEBUTUHAN" -> kebutuhan += tx.amount
                        "TABUNGAN" -> tabungan += tx.amount
                        "BEBAS" -> bebas += tx.amount
                        "DANA_DARURAT" -> danaDarurat += tx.amount
                        "JAJAN" -> jajan += tx.amount
                        "MODAL_USAHA" -> modalUsaha += tx.amount
                        "DANA_CADANGAN" -> cadanganUsaha += tx.amount
                        "SEDEKAH_ZAKAT" -> sedekahUsaha += tx.amount
                    }
                }
                "PENGEMBALIAN_TALANGAN" -> {
                    when (tx.targetPot) {
                        "KEBUTUHAN" -> kebutuhan += tx.amount
                        "TABUNGAN" -> tabungan += tx.amount
                        "BEBAS" -> bebas += tx.amount
                        "DANA_DARURAT" -> danaDarurat += tx.amount
                        "JAJAN" -> jajan += tx.amount
                    }
                }
            }
        }

        var totalPiutangPribadi = 0.0
        var totalPiutangUsaha = 0.0
        var unpaidCount = 0
        var overdueCount = 0
        var totalLended = 0.0
        var totalRepaid = 0.0

        for (loan in loanList) {
            val remaining = (loan.amount - loan.paidAmount).coerceAtLeast(0.0)
            totalLended += loan.amount
            totalRepaid += loan.paidAmount

            if (loan.systemType == "PRIBADI") {
                totalPiutangPribadi += remaining
            } else {
                totalPiutangUsaha += remaining
            }

            if (remaining > 0.01) {
                unpaidCount++
                if (loan.dueDateString.isNotEmpty() && loan.dueDateString <= todayStr) {
                    overdueCount++
                }
            }
        }

        // Active Talangan & Project Summaries
        val projectSummaries = projectList.map { project ->
            val pIncome = txList.filter { it.projectId == project.id && it.transactionType == "PEMASUKAN" && !it.isAutoSplit }.sumOf { it.amount }
            val pExpense = txList.filter { it.projectId == project.id && it.transactionType == "PENGELUARAN" && !it.isAutoSplit && !it.isTalanganReimbursement }.sumOf { it.amount }
            val pTalangan = txList.filter { it.projectId == project.id && it.transactionType == "PENGELUARAN" && !it.isTalanganReimbursement && (it.isTalangan || it.sourcePot in listOf("KEBUTUHAN", "BEBAS", "TABUNGAN", "DANA_DARURAT", "JAJAN")) }.sumOf { it.amount } + (if (project.talanganAmount > 0) project.talanganAmount else 0.0)
            val pRepaid = txList.filter { it.projectId == project.id && (it.transactionType == "PENGEMBALIAN_TALANGAN" || it.isTalanganReimbursement) }.sumOf { it.amount } + txList.filter { it.projectId == project.id && it.talanganAmount > 0 && !it.isAutoSplit }.sumOf { it.talanganAmount }
            val pActiveTalangan = (pTalangan - pRepaid).coerceAtLeast(0.0)
            val pLaba = pIncome - pExpense

            com.example.data.model.ProjectItemSummary(
                project = project,
                totalIncome = pIncome,
                totalExpense = pExpense,
                totalTalangan = pTalangan,
                repaidTalangan = pRepaid,
                activeTalangan = pActiveTalangan,
                laba = pLaba
            )
        }

        val activeTalanganProjects = projectSummaries.filter { it.activeTalangan > 0.01 }
        val activeTalanganCount = activeTalanganProjects.size
        val totalActiveTalangan = activeTalanganProjects.sumOf { it.activeTalangan }

        val totalPribadi = kebutuhan + tabungan + bebas + danaDarurat + jajan
        val totalUsaha = modalUsaha + cadanganUsaha + sedekahUsaha
        val totalBiayaUsaha = totalPengeluaranUsaha + totalBiayaTalangan
        val laba = totalPemasukanUsaha - totalBiayaUsaha

        FinanceSummary(
            totalSaldoPribadi = totalPribadi,
            kebutuhanBalance = kebutuhan,
            tabunganBalance = tabungan,
            bebasBalance = bebas,
            danaDaruratBalance = danaDarurat,
            jajanBalance = jajan,
            totalPemasukanPribadi = totalPemasukanPribadi,
            totalPengeluaranPribadi = totalPengeluaranPribadi,
            terpakaiJajanHariIni = terpakaiJajanHariIni,
            totalSaldoUsaha = totalUsaha,
            modalUsahaBalance = modalUsaha,
            cadanganUsahaBalance = cadanganUsaha,
            sedekahUsahaBalance = sedekahUsaha,
            totalPemasukanUsaha = totalPemasukanUsaha,
            totalPengeluaranUsaha = totalPengeluaranUsaha,
            totalBiayaUsaha = totalBiayaUsaha,
            totalBiayaTalangan = totalBiayaTalangan,
            labaUsaha = laba,
            totalPiutangPribadi = totalPiutangPribadi,
            totalPiutangUsaha = totalPiutangUsaha,
            totalPiutang = totalPiutangPribadi + totalPiutangUsaha,
            unpaidLoansCount = unpaidCount,
            overdueLoansCount = overdueCount,
            totalLendedOut = totalLended,
            totalRepaidIn = totalRepaid,
            activeTalanganCount = activeTalanganCount,
            totalActiveTalangan = totalActiveTalangan,
            projectSummaries = projectSummaries
        )
    }

    suspend fun exportBackupJson(): String {
        val categories = categoryDao.getAllActiveCategories().first()
        val transactions = transactionDao.getAllTransactionsList()
        val settings = settingsDao.getSettings() ?: FinancialSettingsEntity()
        val loans = loanDao.getAllLoansList()
        val repayments = loanDao.getAllRepaymentsList()
        val projects = serviceProjectDao.getAllProjectsList()

        val backupData = BackupData(
            version = 4,
            categories = categories,
            transactions = transactions,
            settings = settings,
            loans = loans,
            loanRepayments = repayments,
            serviceProjects = projects
        )

        val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
        val adapter = moshi.adapter(BackupData::class.java)
        return adapter.toJson(backupData)
    }

    suspend fun restoreBackupJson(jsonString: String): Boolean {
        return try {
            val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
            val adapter = moshi.adapter(BackupData::class.java)
            val backupData = adapter.fromJson(jsonString) ?: return false

            categoryDao.deleteAll()
            transactionDao.deleteAll()
            settingsDao.deleteAll()
            loanDao.deleteAllLoans()
            loanDao.deleteAllRepayments()
            serviceProjectDao.deleteAll()

            categoryDao.insertCategories(backupData.categories)
            transactionDao.insertTransactions(backupData.transactions)
            settingsDao.insertOrUpdateSettings(backupData.settings)
            if (backupData.loans.isNotEmpty()) {
                loanDao.insertLoans(backupData.loans)
            }
            if (backupData.loanRepayments.isNotEmpty()) {
                loanDao.insertRepayments(backupData.loanRepayments)
            }
            if (backupData.serviceProjects.isNotEmpty()) {
                serviceProjectDao.insertProjects(backupData.serviceProjects)
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
