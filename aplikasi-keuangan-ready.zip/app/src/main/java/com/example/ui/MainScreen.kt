package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.SystemType
import com.example.ui.components.AddTransactionBottomSheet
import com.example.ui.screens.BerandaScreen
import com.example.ui.screens.GrafikScreen
import com.example.ui.screens.KelolaKategoriScreen
import com.example.ui.screens.PengaturanScreen
import com.example.ui.screens.PiutangScreen
import com.example.ui.screens.PribadiScreen
import com.example.ui.screens.UsahaScreen
import com.example.ui.viewmodel.FinanceViewModel

enum class NavigationTab(
    val title: String,
    val icon: ImageVector,
    val testTag: String
) {
    PRIBADI("Pribadi", Icons.Default.Person, "tab_pribadi"),
    GRAFIK("Grafik", Icons.Default.BarChart, "tab_grafik"),
    BERANDA("Beranda", Icons.Default.Home, "tab_beranda"),
    USAHA("Usaha", Icons.Default.Store, "tab_usaha"),
    PENGATURAN("Pengaturan", Icons.Default.Settings, "tab_pengaturan")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: FinanceViewModel) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(NavigationTab.BERANDA) }
    var isCategoryManagerOpen by remember { mutableStateOf(false) }
    var isPiutangScreenOpen by remember { mutableStateOf(false) }

    val summary by viewModel.summary.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val restoreMsg by viewModel.restoreMessage.collectAsStateWithLifecycle()

    LaunchedEffect(restoreMsg) {
        restoreMsg?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearRestoreMessage()
        }
    }

    var isAddSheetOpen by remember { mutableStateOf(false) }
    var addSheetInitialSystemType by remember { mutableStateOf(SystemType.PRIBADI) }
    var addSheetInitialType by remember { mutableStateOf(com.example.data.model.TransactionType.PENGELUARAN) }
    var addSheetInitialProjectId by remember { mutableStateOf<Long?>(null) }
    var editingTransaction by remember { mutableStateOf<com.example.data.model.TransactionEntity?>(null) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    if (isCategoryManagerOpen) {
        KelolaKategoriScreen(
            categories = categories,
            onAddCategory = { viewModel.addCategory(it) },
            onUpdateCategory = { viewModel.updateCategory(it) },
            onArchiveCategory = { viewModel.archiveCategory(it) },
            onBack = { isCategoryManagerOpen = false }
        )
    } else if (isPiutangScreenOpen) {
        PiutangScreen(
            viewModel = viewModel,
            summary = summary,
            onBack = { isPiutangScreenOpen = false }
        )
    } else {
        Scaffold(
            bottomBar = {
                NavigationBar(
                    modifier = Modifier
                        .navigationBarsPadding()
                        .testTag("bottom_navigation_bar")
                ) {
                    NavigationTab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = { Icon(tab.icon, contentDescription = tab.title) },
                            label = { Text(tab.title) },
                            modifier = Modifier.testTag(tab.testTag)
                        )
                    }
                }
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = {
                        addSheetInitialSystemType = if (selectedTab == NavigationTab.USAHA) SystemType.USAHA else SystemType.PRIBADI
                        addSheetInitialType = com.example.data.model.TransactionType.PENGELUARAN
                        addSheetInitialProjectId = null
                        isAddSheetOpen = true
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier
                        .padding(bottom = 8.dp)
                        .testTag("fab_add_transaction")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Tambah Transaksi")
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (selectedTab) {
                    NavigationTab.PRIBADI -> {
                        PribadiScreen(
                            summary = summary,
                            settings = settings,
                            pribadiTransactions = transactions.filter { it.systemType == "PRIBADI" && !it.isAutoSplit },
                            onOpenPiutang = { isPiutangScreenOpen = true },
                            onEditTransaction = { editingTransaction = it },
                            onDeleteTransaction = { viewModel.deleteTransaction(it) }
                        )
                    }
                    NavigationTab.GRAFIK -> {
                        GrafikScreen(
                            summary = summary,
                            settings = settings,
                            allTransactions = transactions.filter { !it.isAutoSplit },
                            onEditTransaction = { editingTransaction = it },
                            onDeleteTransaction = { viewModel.deleteTransaction(it) }
                        )
                    }
                    NavigationTab.BERANDA -> {
                        BerandaScreen(
                            summary = summary,
                            settings = settings,
                            recentTransactions = transactions.filter { !it.isAutoSplit },
                            onOpenPiutang = { isPiutangScreenOpen = true },
                            onEditTransaction = { editingTransaction = it },
                            onDeleteTransaction = { viewModel.deleteTransaction(it) }
                        )
                    }
                    NavigationTab.USAHA -> {
                        UsahaScreen(
                            summary = summary,
                            settings = settings,
                            usahaTransactions = transactions.filter { it.systemType == "USAHA" && !it.isAutoSplit },
                            onOpenPiutang = { isPiutangScreenOpen = true },
                            onAddProject = { title, customer, category, target, note ->
                                viewModel.addProject(title, customer, category, target, note)
                            },
                            onUpdateProjectStatus = { id, status ->
                                viewModel.updateProjectStatus(id, status)
                            },
                            onDeleteProject = { id ->
                                viewModel.deleteProject(id)
                            },
                            onQuickTransaction = { projectId, projectTitle, isExpense ->
                                addSheetInitialSystemType = SystemType.USAHA
                                addSheetInitialType = if (isExpense) com.example.data.model.TransactionType.PENGELUARAN else com.example.data.model.TransactionType.PEMASUKAN
                                addSheetInitialProjectId = projectId
                                isAddSheetOpen = true
                            },
                            onRepayTalangan = { projectId, amount, sourceUsahaPot, targetPersonalPot, note ->
                                viewModel.repayTalangan(projectId, amount, sourceUsahaPot, targetPersonalPot, note)
                            },
                            onEditTransaction = { editingTransaction = it },
                            onDeleteTransaction = { viewModel.deleteTransaction(it) }
                        )
                    }
                    NavigationTab.PENGATURAN -> {
                        PengaturanScreen(
                            settings = settings,
                            onSaveSettings = { viewModel.updateSettings(it) },
                            onOpenCategoryManager = { isCategoryManagerOpen = true },
                            onExportBackup = { onJsonReady -> viewModel.exportBackup(onJsonReady) },
                            onRestoreBackup = { jsonStr -> viewModel.restoreBackup(jsonStr) }
                        )
                    }
                }
            }
        }
    }

    if (editingTransaction != null) {
        com.example.ui.components.EditTransactionDialog(
            transaction = editingTransaction!!,
            categories = categories,
            projects = projects,
            onDismiss = { editingTransaction = null },
            onSave = { updated ->
                editingTransaction = null
                viewModel.updateTransaction(updated)
            }
        )
    }

    if (isAddSheetOpen) {
        AddTransactionBottomSheet(
            initialSystemType = addSheetInitialSystemType,
            initialType = addSheetInitialType,
            initialProjectId = addSheetInitialProjectId,
            categories = categories,
            projects = projects,
            projectSummaries = summary.projectSummaries,
            sheetState = sheetState,
            onDismiss = { isAddSheetOpen = false },
            onAddCategory = { name, sys, tx -> viewModel.addCategory(name, sys, tx) },
            onSubmit = { systemType, transactionType, amount, categoryName, dateMillis, dateString, timeString, note, sourcePot, targetPot, talanganAmount, talanganPot, projectId, projectTitle, isTalangan ->
                viewModel.addTransaction(
                    systemType = systemType,
                    transactionType = transactionType,
                    amount = amount,
                    categoryName = categoryName,
                    dateMillis = dateMillis,
                    dateString = dateString,
                    timeString = timeString,
                    note = note,
                    sourcePot = sourcePot,
                    targetPot = targetPot,
                    talanganAmount = talanganAmount,
                    talanganPot = talanganPot,
                    projectId = projectId,
                    projectTitle = projectTitle,
                    isTalangan = isTalangan
                )
            }
        )
    }
}
