package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.CurrencyFormat

@Composable
fun CalculatorKeypad(
    amountString: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val keys = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("000", "0", "BACK")
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Display Area
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            tonalElevation = 2.dp
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Text(
                    text = CurrencyFormat.formatRupiahString(amountString),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.testTag("calculator_display")
                )
            }
        }

        // Keypad Grid
        keys.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                row.forEach { key ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (key == "BACK") MaterialTheme.colorScheme.errorContainer
                                else MaterialTheme.colorScheme.surfaceContainer
                            )
                            .clickable {
                                handleKeyPress(key, amountString, onValueChange)
                            }
                            .testTag("key_$key"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (key == "BACK") {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Backspace,
                                contentDescription = "Hapus",
                                tint = MaterialTheme.colorScheme.onErrorContainer
                            )
                        } else {
                            Text(
                                text = key,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun handleKeyPress(
    key: String,
    currentVal: String,
    onValueChange: (String) -> Unit
) {
    val clean = currentVal.filter { it.isDigit() }
    when (key) {
        "BACK" -> {
            if (clean.length > 1) {
                onValueChange(clean.substring(0, clean.length - 1))
            } else {
                onValueChange("0")
            }
        }
        "000" -> {
            if (clean != "0" && clean.isNotEmpty() && clean.length <= 11) {
                onValueChange(clean + "000")
            }
        }
        "0" -> {
            if (clean != "0" && clean.isNotEmpty() && clean.length <= 13) {
                onValueChange(clean + "0")
            }
        }
        else -> {
            if (clean == "0") {
                onValueChange(key)
            } else if (clean.length <= 13) {
                onValueChange(clean + key)
            }
        }
    }
}
