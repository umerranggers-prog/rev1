package com.example.ui.screens

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FinanceSummary
import com.example.data.model.LoanEntity
import com.example.data.model.LoanRepaymentEntity
import com.example.data.model.SystemType
import com.example.ui.viewmodel.FinanceViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PiutangScreen(
    viewModel: FinanceViewModel,
    summary: FinanceSummary,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val loans by viewModel.loans.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedStatusFilter by remember { mutableStateOf("SEMUA") } // SEMUA, BELUM_LUNAS, SEBAGIAN, LUNAS, JATUH_TEMPO
    var selectedSystemFilter by remember { mutableStateOf("SEMUA") } // SEMUA, PRIBADI, USAHA

    var showAddLoanDialog by remember { mutableStateOf(false) }
    var loanToRepay by remember { mutableStateOf<LoanEntity?>(null) }
    var loanHistoryToShow by remember { mutableStateOf<LoanEntity?>(null) }
    var loanToDelete by remember { mutableStateOf<LoanEntity?>(null) }

    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val todayStr = dateFormat.format(Date())

    // Filter loans
    val filteredLoans = loans.filter { loan ->
        val remaining = (loan.amount - loan.paidAmount).coerceAtLeast(0.0)
        val isOverdue = remaining > 0.01 && loan.dueDateString.isNotEmpty() && loan.dueDateString <= todayStr

        val matchesSearch = loan.borrowerName.contains(searchQuery, ignoreCase = true) ||
                loan.note.contains(searchQuery, ignoreCase = true)

        val matchesSystem = when (selectedSystemFilter) {
            "PRIBADI" -> loan.systemType == "PRIBADI"
            "USAHA" -> loan.systemType == "USAHA"
            else -> true
        }

        val matchesStatus = when (selectedStatusFilter) {
            "BELUM_LUNAS" -> loan.status == "BELUM_LUNAS" && !isOverdue
            "SEBAGIAN" -> loan.status == "SEBAGIAN" && !isOverdue
            "LUNAS" -> loan.status == "LUNAS"
            "JATUH_TEMPO" -> isOverdue
            else -> true
        }

        matchesSearch && matchesSystem && matchesStatus
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "💸 Uang Dipinjamkan (Piutang)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("piutang_back_button")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Summary Header Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Total Piutang Aktif",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                            Text(
                                text = formatRupiah(summary.totalPiutang),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }

                        Button(
                            onClick = { showAddLoanDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("pinjamkan_uang_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Pinjamkan Uang", fontWeight = FontWeight.Bold)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "👤 Pribadi: ${formatRupiah(summary.totalPiutangPribadi)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "🌾 Usaha: ${formatRupiah(summary.totalPiutangUsaha)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🟠 Belum Lunas: ", fontSize = 11.sp)
                                Text("${summary.unpaidLoansCount} orang", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            color = if (summary.overdueLoansCount > 0) Color(0xFFFFEBEE) else MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🔴 Jatuh Tempo: ", fontSize = 11.sp, color = if (summary.overdueLoansCount > 0) Color(0xFFC62828) else Color.Unspecified)
                                Text("${summary.overdueLoansCount}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (summary.overdueLoansCount > 0) Color(0xFFC62828) else Color.Unspecified)
                            }
                        }
                    }
                }
            }

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_piutang_input"),
                placeholder = { Text("Cari nama peminjam...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedStatusFilter == "SEMUA" && selectedSystemFilter == "SEMUA",
                        onClick = {
                            selectedStatusFilter = "SEMUA"
                            selectedSystemFilter = "SEMUA"
                        },
                        label = { Text("Semua") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedStatusFilter == "BELUM_LUNAS",
                        onClick = { selectedStatusFilter = if (selectedStatusFilter == "BELUM_LUNAS") "SEMUA" else "BELUM_LUNAS" },
                        label = { Text("🟠 Belum Lunas") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedStatusFilter == "SEBAGIAN",
                        onClick = { selectedStatusFilter = if (selectedStatusFilter == "SEBAGIAN") "SEMUA" else "SEBAGIAN" },
                        label = { Text("🟡 Sebagian") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedStatusFilter == "JATUH_TEMPO",
                        onClick = { selectedStatusFilter = if (selectedStatusFilter == "JATUH_TEMPO") "SEMUA" else "JATUH_TEMPO" },
                        label = { Text("🔴 Jatuh Tempo") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedStatusFilter == "LUNAS",
                        onClick = { selectedStatusFilter = if (selectedStatusFilter == "LUNAS") "SEMUA" else "LUNAS" },
                        label = { Text("🟢 Lunas") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedSystemFilter == "PRIBADI",
                        onClick = { selectedSystemFilter = if (selectedSystemFilter == "PRIBADI") "SEMUA" else "PRIBADI" },
                        label = { Text("👤 Pribadi") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedSystemFilter == "USAHA",
                        onClick = { selectedSystemFilter = if (selectedSystemFilter == "USAHA") "SEMUA" else "USAHA" },
                        label = { Text("🌾 Usaha") }
                    )
                }
            }

            // Loan List
            if (filteredLoans.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "🤝", fontSize = 40.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Belum ada catatan uang dipinjamkan",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredLoans, key = { it.id }) { loan ->
                        LoanCardItem(
                            loan = loan,
                            todayStr = todayStr,
                            onRepay = { loanToRepay = loan },
                            onShowHistory = { loanHistoryToShow = loan },
                            onDelete = { loanToDelete = loan }
                        )
                    }
                }
            }
        }
    }

    // Dialog 1: Add Loan Dialog
    if (showAddLoanDialog) {
        AddLoanDialog(
            onDismiss = { showAddLoanDialog = false },
            onSubmit = { borrowerName, amount, dateMillis, dateString, dueDateString, note, systemType, sourcePot ->
                viewModel.addLoan(
                    borrowerName = borrowerName,
                    amount = amount,
                    dateMillis = dateMillis,
                    dateString = dateString,
                    dueDateString = dueDateString,
                    note = note,
                    systemType = systemType,
                    sourcePot = sourcePot,
                    onSuccess = {
                        Toast.makeText(context, "Berhasil mencatat pinjaman untuk $borrowerName", Toast.LENGTH_SHORT).show()
                        showAddLoanDialog = false
                    }
                )
            }
        )
    }

    // Dialog 2: Add Repayment Dialog
    loanToRepay?.let { loan ->
        AddRepaymentDialog(
            loan = loan,
            onDismiss = { loanToRepay = null },
            onSubmit = { amount, dateMillis, dateString, timeString, note, targetPot ->
                viewModel.addRepayment(
                    loanId = loan.id,
                    repaymentAmount = amount,
                    dateMillis = dateMillis,
                    dateString = dateString,
                    timeString = timeString,
                    note = note,
                    targetPot = targetPot,
                    onResult = { success, errorMsg ->
                        if (success) {
                            Toast.makeText(context, "Pengembalian berhasil dicatat!", Toast.LENGTH_SHORT).show()
                            loanToRepay = null
                        } else {
                            Toast.makeText(context, errorMsg ?: "Gagal mencatat pengembalian", Toast.LENGTH_LONG).show()
                        }
                    }
                )
            }
        )
    }

    // Dialog 3: Loan History Dialog
    loanHistoryToShow?.let { loan ->
        LoanHistoryDialog(
            loan = loan,
            viewModel = viewModel,
            onDismiss = { loanHistoryToShow = null }
        )
    }

    // Dialog 4: Delete Confirmation Dialog
    loanToDelete?.let { loan ->
        AlertDialog(
            onDismissRequest = { loanToDelete = null },
            title = { Text("Hapus Pinjaman") },
            text = { Text("Apakah Anda yakin ingin menghapus catatan pinjaman atas nama ${loan.borrowerName}?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteLoan(loan.id)
                        loanToDelete = null
                        Toast.makeText(context, "Pinjaman telah dihapus", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text("Hapus", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { loanToDelete = null }) {
                    Text("Batal")
                }
            }
        )
    }
}

@Composable
private fun LoanCardItem(
    loan: LoanEntity,
    todayStr: String,
    onRepay: () -> Unit,
    onShowHistory: () -> Unit,
    onDelete: () -> Unit
) {
    val remaining = (loan.amount - loan.paidAmount).coerceAtLeast(0.0)
    val isOverdue = remaining > 0.01 && loan.dueDateString.isNotEmpty() && loan.dueDateString <= todayStr

    val (statusLabel, statusBg, statusFg) = when {
        remaining <= 0.01 -> Triple("🟢 Lunas", Color(0xFFE8F5E9), Color(0xFF2E7D32))
        isOverdue -> Triple("🔴 Jatuh Tempo", Color(0xFFFFEBEE), Color(0xFFC62828))
        loan.paidAmount > 0 -> Triple("🟡 Sebagian", Color(0xFFFFF8E1), Color(0xFFF57F17))
        else -> Triple("🟠 Belum Lunas", Color(0xFFFFF3E0), Color(0xFFE65100))
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header Row: Borrower Name & Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (loan.systemType == "PRIBADI") "👤" else "🌾",
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = loan.borrowerName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = statusBg
                ) {
                    Text(
                        text = statusLabel,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusFg,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Financial Progress Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "Pinjaman Awal", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(text = formatRupiah(loan.amount), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                Column {
                    Text(text = "Dikembalikan", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(text = formatRupiah(loan.paidAmount), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF2E7D32))
                }
                Column {
                    Text(text = "Sisa Piutang", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(text = formatRupiah(remaining), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (remaining > 0) MaterialTheme.colorScheme.primary else Color(0xFF2E7D32))
                }
            }

            // Date & Notes
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Tanggal: ${loan.dateString}${if (loan.dueDateString.isNotEmpty()) " • Jatuh tempo: ${loan.dueDateString}" else ""}",
                    fontSize = 11.sp,
                    color = if (isOverdue) Color(0xFFC62828) else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = if (isOverdue) FontWeight.Bold else FontWeight.Normal
                )
            }

            if (loan.note.isNotEmpty()) {
                Text(
                    text = "Catatan: ${loan.note}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onShowHistory) {
                    Icon(imageVector = Icons.Default.History, contentDescription = "Riwayat", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = onDelete) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Hapus", tint = MaterialTheme.colorScheme.error)
                }

                if (remaining > 0.01) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Button(
                        onClick = onRepay,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("catat_pengembalian_button_${loan.id}")
                    ) {
                        Icon(imageVector = Icons.Default.Payment, contentDescription = null, modifier = Modifier.padding(end = 4.dp))
                        Text("Catat Pengembalian", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun AddLoanDialog(
    onDismiss: () -> Unit,
    onSubmit: (
        borrowerName: String,
        amount: Double,
        dateMillis: Long,
        dateString: String,
        dueDateString: String,
        note: String,
        systemType: String,
        sourcePot: String
    ) -> Unit
) {
    val context = LocalContext.current
    var borrowerName by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var noteText by remember { mutableStateOf("") }
    var selectedSystem by remember { mutableStateOf(SystemType.PRIBADI) }

    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val nowCalendar = Calendar.getInstance()
    var selectedDateString by remember { mutableStateOf(dateFormat.format(nowCalendar.time)) }
    var selectedDueDateString by remember { mutableStateOf("") }

    val potsPribadi = listOf("KEBUTUHAN" to "Kebutuhan", "BEBAS" to "Bebas", "TABUNGAN" to "Tabungan", "DANA_DARURAT" to "Dana Darurat", "JAJAN" to "Jajan")
    val potsUsaha = listOf("MODAL_USAHA" to "Modal Usaha", "DANA_CADANGAN" to "Dana Cadangan", "SEDEKAH_ZAKAT" to "Sedekah")

    var selectedSourcePot by remember(selectedSystem) {
        mutableStateOf(if (selectedSystem == SystemType.PRIBADI) "KEBUTUHAN" else "MODAL_USAHA")
    }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = "🤝 Pinjamkan Uang", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // System Switcher
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                        .padding(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selectedSystem == SystemType.PRIBADI) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { selectedSystem = SystemType.PRIBADI }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "👤 Pribadi",
                            fontWeight = FontWeight.Bold,
                            color = if (selectedSystem == SystemType.PRIBADI) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selectedSystem == SystemType.USAHA) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { selectedSystem = SystemType.USAHA }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "🌾 Usaha",
                            fontWeight = FontWeight.Bold,
                            color = if (selectedSystem == SystemType.USAHA) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Borrower Name
                OutlinedTextField(
                    value = borrowerName,
                    onValueChange = { borrowerName = it },
                    label = { Text("Nama Peminjam *") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("borrower_name_input")
                )

                // Amount
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { char -> char.isDigit() } },
                    label = { Text("Nominal (Rp) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("loan_amount_input")
                )

                // Source Pot Selection
                Text(text = "Sumber Dana:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val potsList = if (selectedSystem == SystemType.PRIBADI) potsPribadi else potsUsaha
                    items(potsList) { (potKey, potLabel) ->
                        FilterChip(
                            selected = selectedSourcePot == potKey,
                            onClick = { selectedSourcePot = potKey },
                            label = { Text(potLabel) }
                        )
                    }
                }

                // Date and Due Date
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = selectedDateString,
                        onValueChange = { selectedDateString = it },
                        label = { Text("Tanggal Pinjam") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = selectedDueDateString,
                        onValueChange = { selectedDueDateString = it },
                        label = { Text("Jatuh Tempo (Opsional)") },
                        placeholder = { Text("YYYY-MM-DD") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Note
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text("Catatan (Opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(text = errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull()
                    if (borrowerName.isBlank()) {
                        errorMessage = "Nama peminjam wajib diisi"
                        return@Button
                    }
                    if (amount == null || amount <= 0) {
                        errorMessage = "Nominal harus lebih dari 0"
                        return@Button
                    }

                    onSubmit(
                        borrowerName,
                        amount,
                        System.currentTimeMillis(),
                        selectedDateString,
                        selectedDueDateString,
                        noteText,
                        selectedSystem.name,
                        selectedSourcePot
                    )
                },
                modifier = Modifier.testTag("submit_pinjamkan_uang_button")
            ) {
                Text("Simpan Pinjaman")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
private fun AddRepaymentDialog(
    loan: LoanEntity,
    onDismiss: () -> Unit,
    onSubmit: (
        amount: Double,
        dateMillis: Long,
        dateString: String,
        timeString: String,
        note: String,
        targetPot: String
    ) -> Unit
) {
    val remaining = loan.amount - loan.paidAmount
    var amountText by remember { mutableStateOf("") }
    var noteText by remember { mutableStateOf("") }

    val potsPribadi = listOf("KEBUTUHAN" to "Kebutuhan", "BEBAS" to "Bebas", "TABUNGAN" to "Tabungan", "DANA_DARURAT" to "Dana Darurat", "JAJAN" to "Jajan")
    val potsUsaha = listOf("MODAL_USAHA" to "Modal Usaha", "DANA_CADANGAN" to "Dana Cadangan", "SEDEKAH_ZAKAT" to "Sedekah")

    var selectedTargetPot by remember {
        mutableStateOf(if (loan.systemType == "PRIBADI") "KEBUTUHAN" else "MODAL_USAHA")
    }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    val nowMillis = System.currentTimeMillis()
    val dateString = dateFormat.format(Date(nowMillis))
    val timeString = timeFormat.format(Date(nowMillis))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "💰 Catat Pengembalian", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(text = "Peminjam: ${loan.borrowerName}", fontWeight = FontWeight.Bold)
                        Text(text = "Sisa Pinjaman: ${formatRupiah(remaining)}", fontSize = 13.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    }
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it.filter { char -> char.isDigit() }
                        val valInput = amountText.toDoubleOrNull() ?: 0.0
                        errorMessage = if (valInput > remaining + 0.01) {
                            "Nominal pengembalian melebihi sisa pinjaman."
                        } else {
                            null
                        }
                    },
                    label = { Text("Nominal Pengembalian (Rp) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    isError = errorMessage != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("repayment_amount_input")
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.testTag("repayment_error_message")
                    )
                }

                Text(text = "Masukkan ke Pos:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val potsList = if (loan.systemType == "PRIBADI") potsPribadi else potsUsaha
                    items(potsList) { (potKey, potLabel) ->
                        FilterChip(
                            selected = selectedTargetPot == potKey,
                            onClick = { selectedTargetPot = potKey },
                            label = { Text(potLabel) }
                        )
                    }
                }

                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text("Catatan (Opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull()
                    if (amount == null || amount <= 0) {
                        errorMessage = "Nominal harus lebih dari 0"
                        return@Button
                    }
                    if (amount > remaining + 0.01) {
                        errorMessage = "Nominal pengembalian melebihi sisa pinjaman."
                        return@Button
                    }

                    onSubmit(amount, nowMillis, dateString, timeString, noteText, selectedTargetPot)
                },
                enabled = errorMessage == null,
                modifier = Modifier.testTag("submit_repayment_button")
            ) {
                Text("Simpan Pengembalian")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
private fun LoanHistoryDialog(
    loan: LoanEntity,
    viewModel: FinanceViewModel,
    onDismiss: () -> Unit
) {
    val repayments by viewModel.getRepaymentsFlow(loan.id).collectAsState(initial = emptyList())
    val remaining = (loan.amount - loan.paidAmount).coerceAtLeast(0.0)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("📜 Riwayat Pinjaman ${loan.borrowerName}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Awal: ${formatRupiah(loan.amount)}", fontSize = 12.sp)
                        Text("Dikembalikan: ${formatRupiah(loan.paidAmount)}", fontSize = 12.sp, color = Color(0xFF2E7D32))
                        Text("Sisa: ${formatRupiah(remaining)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Text("Riwayat Pengembalian:", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                if (repayments.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Belum ada pengembalian", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(repayments, key = { it.id }) { item ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("💰 ${formatRupiah(item.amount)}", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                                        Text("${item.dateString} ${item.timeString}${if (item.note.isNotEmpty()) " • ${item.note}" else ""}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text("Pos: ${item.targetPot}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Tutup")
            }
        }
    )
}

private fun formatRupiah(amount: Double): String {
    val formatter = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    formatter.maximumFractionDigits = 0
    return formatter.format(amount)
}
