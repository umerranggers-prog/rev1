package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FinancialSettingsEntity
import com.example.data.model.FinanceSummary
import com.example.data.model.SystemType
import com.example.data.model.TransactionEntity
import com.example.ui.components.CategoryDetailBottomSheet
import com.example.ui.components.TransactionDetailDialog
import com.example.util.CurrencyFormat
import java.util.Calendar

enum class TimePeriod(val label: String) {
    WEEK("Minggu Ini"),
    MONTH("Bulan Ini"),
    YEAR("Tahun Ini"),
    ALL("Semua")
}

data class CategoryDetailState(
    val title: String,
    val transactionType: String?, // "PENGELUARAN", "PEMASUKAN", or null
    val isPot: Boolean = false,
    val potKey: String? = null,
    val isAllOfType: Boolean = false,
    val periodLabel: String,
    val systemLabel: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GrafikScreen(
    summary: FinanceSummary,
    settings: FinancialSettingsEntity? = null,
    allTransactions: List<TransactionEntity>,
    onEditTransaction: ((TransactionEntity) -> Unit)? = null,
    onDeleteTransaction: ((Long) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var selectedSystem by remember { mutableStateOf(SystemType.PRIBADI) }
    var selectedPeriod by remember { mutableStateOf(TimePeriod.MONTH) }
    var selectedCategoryType by remember { mutableStateOf("PENGELUARAN") } // "PENGELUARAN" or "PEMASUKAN"

    var selectedCategoryDetail by remember { mutableStateOf<CategoryDetailState?>(null) }
    var selectedTxForDialog by remember { mutableStateOf<TransactionEntity?>(null) }

    val filteredTx = remember(allTransactions, selectedSystem, selectedPeriod) {
        val startCal = Calendar.getInstance().apply {
            when (selectedPeriod) {
                TimePeriod.WEEK -> add(Calendar.DAY_OF_YEAR, -7)
                TimePeriod.MONTH -> add(Calendar.MONTH, -1)
                TimePeriod.YEAR -> add(Calendar.YEAR, -1)
                TimePeriod.ALL -> set(1970, 0, 1)
            }
        }
        val startMillis = startCal.timeInMillis

        allTransactions.filter {
            it.systemType == selectedSystem.name && it.dateMillis >= startMillis
        }
    }

    val totalIncome = filteredTx.filter { it.transactionType == "PEMASUKAN" }.sumOf { it.amount }
    val totalExpense = filteredTx.filter { it.transactionType == "PENGELUARAN" }.sumOf { it.amount }

    // Category breakdown for expenses
    val expenseCategoryMap = remember(filteredTx) {
        filteredTx.filter { it.transactionType == "PENGELUARAN" }
            .groupBy { it.categoryName }
            .mapValues { entry -> entry.value.sumOf { it.amount } }
            .entries.sortedByDescending { it.value }
    }

    // Category breakdown for income
    val incomeCategoryMap = remember(filteredTx) {
        filteredTx.filter { it.transactionType == "PEMASUKAN" }
            .groupBy { it.categoryName }
            .mapValues { entry -> entry.value.sumOf { it.amount } }
            .entries.sortedByDescending { it.value }
    }

    // Filter transactions for the selected category detail sheet
    val categoryTransactions = remember(filteredTx, selectedCategoryDetail) {
        if (selectedCategoryDetail == null) emptyList()
        else {
            val detail = selectedCategoryDetail!!
            filteredTx.filter { tx ->
                when {
                    detail.isAllOfType -> {
                        detail.transactionType == null || tx.transactionType == detail.transactionType
                    }
                    detail.isPot -> {
                        val key = detail.potKey ?: ""
                        tx.sourcePot.equals(key, ignoreCase = true) ||
                        tx.targetPot?.equals(key, ignoreCase = true) == true ||
                        tx.categoryName.contains(detail.title, ignoreCase = true)
                    }
                    else -> {
                        val matchesCat = tx.categoryName.equals(detail.title, ignoreCase = true)
                        val matchesType = detail.transactionType == null || tx.transactionType == detail.transactionType
                        matchesCat && matchesType
                    }
                }
            }.sortedWith(
                compareByDescending<TransactionEntity> { it.dateMillis }
                    .thenByDescending { it.id }
            )
        }
    }

    // Detail Bottom Sheet when category is pressed
    if (selectedCategoryDetail != null) {
        CategoryDetailBottomSheet(
            categoryTitle = selectedCategoryDetail!!.title,
            transactionType = selectedCategoryDetail!!.transactionType,
            periodLabel = selectedCategoryDetail!!.periodLabel,
            systemLabel = selectedCategoryDetail!!.systemLabel,
            transactions = categoryTransactions,
            onDismiss = { selectedCategoryDetail = null },
            onSelectTransaction = { tx -> selectedTxForDialog = tx }
        )
    }

    // Transaction Detail Dialog (Edit / Delete)
    if (selectedTxForDialog != null) {
        TransactionDetailDialog(
            transaction = selectedTxForDialog!!,
            settings = settings,
            onDismiss = { selectedTxForDialog = null },
            onEdit = onEditTransaction,
            onDelete = onDeleteTransaction
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "📊 Grafik & Laporan Keuangan",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.testTag("grafik_title")
            )
        }

        // System Switcher (Pribadi / Usaha)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (selectedSystem == SystemType.PRIBADI) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                        .clickable { selectedSystem = SystemType.PRIBADI }
                        .padding(vertical = 10.dp)
                        .testTag("tab_grafik_pribadi"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "👤 Laporan Pribadi",
                        fontWeight = FontWeight.Bold,
                        color = if (selectedSystem == SystemType.PRIBADI) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (selectedSystem == SystemType.USAHA) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                        .clickable { selectedSystem = SystemType.USAHA }
                        .padding(vertical = 10.dp)
                        .testTag("tab_grafik_usaha"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🌾 Laporan Usaha",
                        fontWeight = FontWeight.Bold,
                        color = if (selectedSystem == SystemType.USAHA) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // Period Filters
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TimePeriod.entries.forEach { period ->
                    FilterChip(
                        selected = selectedPeriod == period,
                        onClick = { selectedPeriod = period },
                        label = { Text(period.label, fontSize = 12.sp) },
                        modifier = Modifier.testTag("period_chip_${period.name}")
                    )
                }
            }
        }

        // Summary Comparison Card (Pemasukan vs Pengeluaran - Clickable to see transactions)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Ringkasan Perbandingan", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.outline
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Ketuk untuk rincian", fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Total Pemasukan Box (Clickable)
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    selectedCategoryDetail = CategoryDetailState(
                                        title = "Semua Pemasukan",
                                        transactionType = "PEMASUKAN",
                                        isAllOfType = true,
                                        periodLabel = selectedPeriod.label,
                                        systemLabel = if (selectedSystem == SystemType.PRIBADI) "Pribadi" else "Usaha"
                                    )
                                }
                                .padding(4.dp),
                            color = Color.Transparent
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Total Pemasukan", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.ChevronRight,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = Color(0xFF2E7D32)
                                    )
                                }
                                Text(
                                    CurrencyFormat.formatRupiah(totalIncome),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = Color(0xFF2E7D32)
                                )
                            }
                        }

                        // Total Pengeluaran Box (Clickable)
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    selectedCategoryDetail = CategoryDetailState(
                                        title = "Semua Pengeluaran",
                                        transactionType = "PENGELUARAN",
                                        isAllOfType = true,
                                        periodLabel = selectedPeriod.label,
                                        systemLabel = if (selectedSystem == SystemType.PRIBADI) "Pribadi" else "Usaha"
                                    )
                                }
                                .padding(4.dp),
                            color = Color.Transparent
                        ) {
                            Column(horizontalAlignment = Alignment.End) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Total Pengeluaran", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.ChevronRight,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                                Text(
                                    CurrencyFormat.formatRupiah(totalExpense),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }

                    // Bar Ratio Comparison (Clickable)
                    val grandTotal = (totalIncome + totalExpense).coerceAtLeast(1.0)
                    val incomeRatio = (totalIncome / grandTotal).toFloat()
                    val expenseRatio = (totalExpense / grandTotal).toFloat()

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(20.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surfaceContainer)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(incomeRatio.coerceAtLeast(0.01f))
                                    .fillMaxSize()
                                    .background(Color(0xFF2E7D32))
                                    .clickable {
                                        selectedCategoryDetail = CategoryDetailState(
                                            title = "Semua Pemasukan",
                                            transactionType = "PEMASUKAN",
                                            isAllOfType = true,
                                            periodLabel = selectedPeriod.label,
                                            systemLabel = if (selectedSystem == SystemType.PRIBADI) "Pribadi" else "Usaha"
                                        )
                                    }
                            )
                            Box(
                                modifier = Modifier
                                    .weight(expenseRatio.coerceAtLeast(0.01f))
                                    .fillMaxSize()
                                    .background(MaterialTheme.colorScheme.error)
                                    .clickable {
                                        selectedCategoryDetail = CategoryDetailState(
                                            title = "Semua Pengeluaran",
                                            transactionType = "PENGELUARAN",
                                            isAllOfType = true,
                                            periodLabel = selectedPeriod.label,
                                            systemLabel = if (selectedSystem == SystemType.PRIBADI) "Pribadi" else "Usaha"
                                        )
                                    }
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${(incomeRatio * 100).toInt()}% Masuk", fontSize = 11.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.SemiBold)
                            Text("${(expenseRatio * 100).toInt()}% Keluar", fontSize = 11.sp, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        // Piutang Analytics Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("💸 Laporan Piutang & Pinjaman", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Uang Dipinjamkan", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                            Text(
                                CurrencyFormat.formatRupiah(summary.totalLendedOut),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Column {
                            Text("Uang Dikembalikan", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                            Text(
                                CurrencyFormat.formatRupiah(summary.totalRepaidIn),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF2E7D32)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Sisa Piutang", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                            Text(
                                CurrencyFormat.formatRupiah(summary.totalPiutang),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }

        // INTERACTIVE CATEGORY GRAPH CARD (Pengeluaran & Pemasukan)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_category_breakdown"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Header with Hint
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Grafik Kategori Transaksi", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(
                                "Ketuk bagian kategori untuk melihat rincian",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.TouchApp,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Toggle Chips: Pengeluaran vs Pemasukan
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedCategoryType == "PENGELUARAN",
                            onClick = { selectedCategoryType = "PENGELUARAN" },
                            label = { Text("🔴 Pengeluaran (${expenseCategoryMap.size})", fontSize = 12.sp) },
                            modifier = Modifier.testTag("filter_chip_pengeluaran")
                        )

                        FilterChip(
                            selected = selectedCategoryType == "PEMASUKAN",
                            onClick = { selectedCategoryType = "PEMASUKAN" },
                            label = { Text("🟢 Pemasukan (${incomeCategoryMap.size})", fontSize = 12.sp) },
                            modifier = Modifier.testTag("filter_chip_pemasukan")
                        )
                    }

                    // Render Category Bars
                    if (selectedCategoryType == "PENGELUARAN") {
                        if (expenseCategoryMap.isEmpty()) {
                            Text(
                                "Belum ada pengeluaran pada periode ini.",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else {
                            val maxExpense = totalExpense.coerceAtLeast(1.0)
                            expenseCategoryMap.forEach { (categoryName, amount) ->
                                val pct = (amount / maxExpense).toFloat()
                                val txCount = filteredTx.count { it.transactionType == "PENGELUARAN" && it.categoryName.equals(categoryName, ignoreCase = true) }

                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable {
                                            selectedCategoryDetail = CategoryDetailState(
                                                title = categoryName,
                                                transactionType = "PENGELUARAN",
                                                periodLabel = selectedPeriod.label,
                                                systemLabel = if (selectedSystem == SystemType.PRIBADI) "Pribadi" else "Usaha"
                                            )
                                        }
                                        .testTag("category_chart_item_$categoryName"),
                                    color = Color.Transparent
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 6.dp, horizontal = 4.dp),
                                        verticalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Text(categoryName, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = MaterialTheme.colorScheme.surfaceVariant
                                                ) {
                                                    Text(
                                                        "$txCount trx",
                                                        fontSize = 10.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                    )
                                                }
                                                Icon(
                                                    imageVector = Icons.Default.ChevronRight,
                                                    contentDescription = "Lihat rincian",
                                                    modifier = Modifier.size(16.dp),
                                                    tint = MaterialTheme.colorScheme.outline
                                                )
                                            }

                                            Text(
                                                "${CurrencyFormat.formatRupiah(amount)} (${(pct * 100).toInt()}%)",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.error
                                            )
                                        }

                                        LinearProgressIndicator(
                                            progress = { pct },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(8.dp)
                                                .clip(RoundedCornerShape(4.dp)),
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        // PEMASUKAN Categories
                        if (incomeCategoryMap.isEmpty()) {
                            Text(
                                "Belum ada pemasukan pada periode ini.",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else {
                            val maxIncome = totalIncome.coerceAtLeast(1.0)
                            incomeCategoryMap.forEach { (categoryName, amount) ->
                                val pct = (amount / maxIncome).toFloat()
                                val txCount = filteredTx.count { it.transactionType == "PEMASUKAN" && it.categoryName.equals(categoryName, ignoreCase = true) }

                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable {
                                            selectedCategoryDetail = CategoryDetailState(
                                                title = categoryName,
                                                transactionType = "PEMASUKAN",
                                                periodLabel = selectedPeriod.label,
                                                systemLabel = if (selectedSystem == SystemType.PRIBADI) "Pribadi" else "Usaha"
                                            )
                                        }
                                        .testTag("category_chart_income_$categoryName"),
                                    color = Color.Transparent
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 6.dp, horizontal = 4.dp),
                                        verticalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Text(categoryName, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = Color(0xFFE8F5E9)
                                                ) {
                                                    Text(
                                                        "$txCount trx",
                                                        fontSize = 10.sp,
                                                        color = Color(0xFF2E7D32),
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                    )
                                                }
                                                Icon(
                                                    imageVector = Icons.Default.ChevronRight,
                                                    contentDescription = "Lihat rincian",
                                                    modifier = Modifier.size(16.dp),
                                                    tint = MaterialTheme.colorScheme.outline
                                                )
                                            }

                                            Text(
                                                "${CurrencyFormat.formatRupiah(amount)} (${(pct * 100).toInt()}%)",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = Color(0xFF2E7D32)
                                            )
                                        }

                                        LinearProgressIndicator(
                                            progress = { pct },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(8.dp)
                                                .clip(RoundedCornerShape(4.dp)),
                                            color = Color(0xFF2E7D32)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Pot Distribution Breakdown (Pribadi / Usaha - Clickable)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_pot_breakdown"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (selectedSystem == SystemType.PRIBADI) "Komposisi Pos Pribadi Saat Ini"
                            else "Komposisi Pos Usaha Saat Ini",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.outline
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Ketuk rincian pos", fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                        }
                    }

                    if (selectedSystem == SystemType.PRIBADI) {
                        val totalP = summary.totalSaldoPribadi.coerceAtLeast(1.0)
                        val pots = listOf(
                            Triple("Kebutuhan", "Kebutuhan (50%)", summary.kebutuhanBalance),
                            Triple("Tabungan", "Tabungan (20%)", summary.tabunganBalance),
                            Triple("Bebas", "Bebas (20%)", summary.bebasBalance),
                            Triple("Dana Darurat", "Dana Darurat (10%)", summary.danaDaruratBalance),
                            Triple("Uang Jajan", "Uang Jajan", summary.jajanBalance)
                        )
                        pots.forEach { (potKey, label, valAmt) ->
                            val p = (valAmt / totalP).toFloat().coerceIn(0f, 1f)
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        selectedCategoryDetail = CategoryDetailState(
                                            title = label,
                                            transactionType = null,
                                            isPot = true,
                                            potKey = when (potKey) {
                                                "Kebutuhan" -> "KEBUTUHAN"
                                                "Tabungan" -> "TABUNGAN"
                                                "Bebas" -> "BEBAS"
                                                "Dana Darurat" -> "DANA_DARURAT"
                                                "Uang Jajan" -> "JAJAN"
                                                else -> potKey
                                            },
                                            periodLabel = selectedPeriod.label,
                                            systemLabel = "Pribadi"
                                        )
                                    }
                                    .padding(vertical = 4.dp, horizontal = 2.dp),
                                color = Color.Transparent
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(
                                                imageVector = Icons.Default.ChevronRight,
                                                contentDescription = null,
                                                modifier = Modifier.size(14.dp),
                                                tint = MaterialTheme.colorScheme.outline
                                            )
                                        }
                                        Text(CurrencyFormat.formatRupiah(valAmt), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                    LinearProgressIndicator(
                                        progress = { p },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                    )
                                }
                            }
                        }
                    } else {
                        val totalU = summary.totalSaldoUsaha.coerceAtLeast(1.0)
                        val pots = listOf(
                            Triple("Modal Usaha", "Modal Usaha (30%)", summary.modalUsahaBalance),
                            Triple("Dana Cadangan", "Dana Cadangan (20%)", summary.cadanganUsahaBalance),
                            Triple("Sedekah/Zakat", "Sedekah/Zakat (10%)", summary.sedekahUsahaBalance)
                        )
                        pots.forEach { (potKey, label, valAmt) ->
                            val p = (valAmt / totalU).toFloat().coerceIn(0f, 1f)
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        selectedCategoryDetail = CategoryDetailState(
                                            title = label,
                                            transactionType = null,
                                            isPot = true,
                                            potKey = when (potKey) {
                                                "Modal Usaha" -> "MODAL_USAHA"
                                                "Dana Cadangan" -> "DANA_CADANGAN"
                                                "Sedekah/Zakat" -> "SEDEKAH_ZAKAT"
                                                else -> potKey
                                            },
                                            periodLabel = selectedPeriod.label,
                                            systemLabel = "Usaha"
                                        )
                                    }
                                    .padding(vertical = 4.dp, horizontal = 2.dp),
                                color = Color.Transparent
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(
                                                imageVector = Icons.Default.ChevronRight,
                                                contentDescription = null,
                                                modifier = Modifier.size(14.dp),
                                                tint = MaterialTheme.colorScheme.outline
                                            )
                                        }
                                        Text(CurrencyFormat.formatRupiah(valAmt), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                    LinearProgressIndicator(
                                        progress = { p },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp)),
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
