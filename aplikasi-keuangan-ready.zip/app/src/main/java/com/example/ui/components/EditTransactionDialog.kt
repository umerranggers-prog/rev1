package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CategoryEntity
import com.example.data.model.ServiceProjectEntity
import com.example.data.model.TransactionEntity
import com.example.util.CurrencyFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditTransactionDialog(
    transaction: TransactionEntity,
    categories: List<CategoryEntity> = emptyList(),
    projects: List<ServiceProjectEntity> = emptyList(),
    onDismiss: () -> Unit,
    onSave: (TransactionEntity) -> Unit
) {
    var amountText by remember { mutableStateOf(transaction.amount.toLong().toString()) }
    var selectedCategory by remember { mutableStateOf(transaction.categoryName) }
    var dateString by remember { mutableStateOf(transaction.dateString) }
    var timeString by remember { mutableStateOf(transaction.timeString) }
    var note by remember { mutableStateOf(transaction.note) }
    var selectedSourcePot by remember { mutableStateOf(transaction.sourcePot) }
    var selectedProjectId by remember { mutableStateOf(transaction.projectId) }

    val isPribadi = transaction.systemType == "PRIBADI"
    val isExpense = transaction.transactionType == "PENGELUARAN"

    val relevantCategories = remember(categories, transaction.systemType, transaction.transactionType) {
        val filtered = categories.filter {
            it.systemType == transaction.systemType && it.transactionType == transaction.transactionType
        }
        if (filtered.any { it.name == transaction.categoryName }) {
            filtered
        } else {
            listOf(CategoryEntity(name = transaction.categoryName, iconName = "Category", systemType = transaction.systemType, transactionType = transaction.transactionType)) + filtered
        }
    }

    val potOptions = if (isPribadi) {
        listOf(
            "KEBUTUHAN" to "🏠 Kebutuhan",
            "JAJAN" to "🍜 Jajan",
            "TABUNGAN" to "💰 Tabungan",
            "BEBAS" to "🎮 Bebas",
            "DANA_DARURAT" to "🛡️ Dana Darurat"
        )
    } else {
        listOf(
            "MODAL_USAHA" to "💼 Modal Usaha",
            "DANA_CADANGAN" to "🛡️ Dana Cadangan",
            "SEDEKAH_ZAKAT" to "🤲 Sedekah/Zakat"
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Edit Transaksi",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Nominal Input
                Column {
                    Text(
                        text = "Nominal (Rp)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { input ->
                            val digitsOnly = input.filter { it.isDigit() }
                            amountText = digitsOnly
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_amount_input"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        prefix = { Text("Rp ", fontWeight = FontWeight.Bold) },
                        shape = RoundedCornerShape(10.dp)
                    )
                    val parsedAmt = amountText.toDoubleOrNull() ?: 0.0
                    Text(
                        text = CurrencyFormat.formatRupiah(parsedAmt),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 2.dp, start = 4.dp)
                    )
                }

                // Kategori Selector
                Column {
                    Text(
                        text = "Kategori",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        relevantCategories.forEach { cat ->
                            FilterChip(
                                selected = selectedCategory == cat.name,
                                onClick = { selectedCategory = cat.name },
                                label = { Text(cat.name, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }
                }

                // Pos / Dompet Selector (for Pengeluaran)
                if (isExpense && potOptions.isNotEmpty()) {
                    Column {
                        Text(
                            text = "Sumber Pos / Dompet",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            potOptions.forEach { (potKey, potLabel) ->
                                FilterChip(
                                    selected = selectedSourcePot == potKey,
                                    onClick = { selectedSourcePot = potKey },
                                    label = { Text(potLabel, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                        selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                )
                            }
                        }
                    }
                }

                // Project Selector (if Usaha or has projects)
                if (projects.isNotEmpty() && !isPribadi) {
                    Column {
                        Text(
                            text = "Hubungkan ke Project (Opsional)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = selectedProjectId == null,
                                onClick = { selectedProjectId = null },
                                label = { Text("Tanpa Project", fontSize = 11.sp) }
                            )
                            projects.forEach { proj ->
                                FilterChip(
                                    selected = selectedProjectId == proj.id,
                                    onClick = { selectedProjectId = proj.id },
                                    label = { Text("📁 ${proj.title}", fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }

                // Tanggal & Waktu
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = dateString,
                        onValueChange = { dateString = it },
                        label = { Text("Tanggal (YYYY-MM-DD)", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = timeString,
                        onValueChange = { timeString = it },
                        label = { Text("Waktu (HH:MM)", fontSize = 11.sp) },
                        modifier = Modifier.weight(0.7f),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                // Catatan
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Catatan", fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalAmount = amountText.toDoubleOrNull() ?: transaction.amount
                    if (finalAmount > 0) {
                        val parsedMillis = try {
                            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                            sdf.parse("$dateString $timeString")?.time ?: transaction.dateMillis
                        } catch (e: Exception) {
                            transaction.dateMillis
                        }

                        val selectedProjObj = projects.firstOrNull { it.id == selectedProjectId }
                        val finalProjectTitle = selectedProjObj?.title ?: transaction.projectTitle

                        val updated = transaction.copy(
                            amount = finalAmount,
                            categoryName = selectedCategory,
                            dateMillis = parsedMillis,
                            dateString = dateString,
                            timeString = timeString,
                            note = note,
                            sourcePot = if (selectedSourcePot.isNotEmpty()) selectedSourcePot else transaction.sourcePot,
                            projectId = selectedProjectId,
                            projectTitle = if (selectedProjectId != null) finalProjectTitle else null
                        )
                        onSave(updated)
                    }
                },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("btn_save_edit_transaction")
            ) {
                Text("Simpan Perubahan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
