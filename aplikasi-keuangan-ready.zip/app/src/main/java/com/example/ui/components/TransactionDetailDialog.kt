package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FinancialSettingsEntity
import com.example.data.model.TransactionEntity
import com.example.util.CurrencyFormat

@Composable
fun TransactionDetailDialog(
    transaction: TransactionEntity,
    settings: FinancialSettingsEntity? = null,
    onDismiss: () -> Unit,
    onEdit: ((TransactionEntity) -> Unit)? = null,
    onDelete: ((Long) -> Unit)? = null
) {
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Hapus Transaksi?", fontWeight = FontWeight.Bold) },
            text = {
                Text("Apakah Anda yakin ingin menghapus transaksi ini? Saldo, laporan, dan grafik akan otomatis disesuaikan.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        onDelete?.invoke(transaction.id)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_confirm_delete_transaction")
                ) {
                    Text("Hapus")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }
    val isFromUsahaShare = transaction.originSystemType == "USAHA" ||
            transaction.note.contains("dari Usaha", ignoreCase = true) ||
            (transaction.systemType == "PRIBADI" && transaction.sourcePot == "USAHA")

    val isTalanganReimbursement = transaction.isTalanganReimbursement ||
            transaction.transactionType == "PENGEMBALIAN_TALANGAN"

    val isUsahaParentIncome = transaction.systemType == "USAHA" &&
            transaction.transactionType == "PEMASUKAN"

    val usahaPribadiPct = settings?.usahaPribadiPct?.toInt() ?: 40
    val usahaModalPct = settings?.usahaModalPct?.toInt() ?: 30
    val usahaCadanganPct = settings?.usahaCadanganPct?.toInt() ?: 20
    val usahaSedekahPct = settings?.usahaSedekahPct?.toInt() ?: 10

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isTalanganReimbursement -> Color(0xFFE8F5E9)
                                    isFromUsahaShare -> Color(0xFFE3F2FD)
                                    transaction.transactionType == "PEMASUKAN" -> Color(0xFFE8F5E9)
                                    else -> Color(0xFFFFEBEE)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = when {
                                isTalanganReimbursement -> "↩️"
                                isFromUsahaShare -> "🌾"
                                transaction.systemType == "USAHA" -> "🌾"
                                else -> "👤"
                            },
                            fontSize = 18.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Detail Transaksi",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = when {
                                isTalanganReimbursement -> "Pengembalian Talangan"
                                isFromUsahaShare -> "$usahaPribadiPct% Bagian dari Usaha"
                                isUsahaParentIncome -> "Pemasukan Hasil Usaha"
                                transaction.systemType == "PRIBADI" -> "Transaksi Pribadi"
                                else -> "Transaksi Usaha"
                            },
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Nominal Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = when {
                                isTalanganReimbursement -> "Dana Talangan Kembali"
                                isFromUsahaShare -> "Masuk ke Pribadi ($usahaPribadiPct%)"
                                transaction.transactionType == "PEMASUKAN" -> "Total Pemasukan"
                                else -> "Jumlah Pengeluaran"
                            },
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        val prefix = when (transaction.transactionType) {
                            "PEMASUKAN", "PENGEMBALIAN", "PENGEMBALIAN_TALANGAN" -> "+"
                            else -> "-"
                        }
                        val amountColor = when (transaction.transactionType) {
                            "PEMASUKAN", "PENGEMBALIAN", "PENGEMBALIAN_TALANGAN" -> Color(0xFF2E7D32)
                            else -> MaterialTheme.colorScheme.error
                        }
                        Text(
                            text = "$prefix ${CurrencyFormat.formatRupiah(transaction.amount)}",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = amountColor
                        )

                        if (isTalanganReimbursement) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                color = Color(0xFFFFF3E0),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "↩️ Bukan Pendapatan Baru (Talangan Kembali)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFE65100),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }

                // Information Rows
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DetailRow(
                        label = "Sumber",
                        value = if (isFromUsahaShare || transaction.systemType == "USAHA") "🌾 Usaha" else "👤 Pribadi"
                    )

                    DetailRow(
                        label = "Kategori",
                        value = transaction.sourceCategoryName?.ifEmpty { transaction.categoryName } ?: transaction.categoryName
                    )

                    if (!transaction.projectTitle.isNullOrEmpty()) {
                        DetailRow(
                            label = "Project Usaha",
                            value = "📁 ${transaction.projectTitle}"
                        )
                    }

                    // If transaction is 40% from business, show comprehensive connection
                    if (isFromUsahaShare) {
                        val gross = if (transaction.originalGrossAmount > 0) transaction.originalGrossAmount else (transaction.amount / (usahaPribadiPct / 100.0))
                        val profit = if (transaction.originalProfitAmount > 0) transaction.originalProfitAmount else gross

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                        DetailRow(
                            label = "Total Hasil Usaha",
                            value = CurrencyFormat.formatRupiah(gross),
                            valueWeight = FontWeight.Bold
                        )

                        DetailRow(
                            label = "Bagian Pribadi",
                            value = "$usahaPribadiPct% dari Hasil Usaha"
                        )

                        DetailRow(
                            label = "Masuk ke Pribadi",
                            value = CurrencyFormat.formatRupiah(transaction.amount),
                            valueColor = Color(0xFF2E7D32),
                            valueWeight = FontWeight.Bold
                        )

                        // Split detail in Pribadi
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = "Otomatis dialokasikan ke pos pribadi:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Text("• 50% Kebutuhan: ${CurrencyFormat.formatRupiah(transaction.amount * 0.50)}", fontSize = 11.sp)
                                Text("• 20% Tabungan: ${CurrencyFormat.formatRupiah(transaction.amount * 0.20)}", fontSize = 11.sp)
                                Text("• 20% Bebas: ${CurrencyFormat.formatRupiah(transaction.amount * 0.20)}", fontSize = 11.sp)
                                Text("• 10% Dana Darurat: ${CurrencyFormat.formatRupiah(transaction.amount * 0.10)}", fontSize = 11.sp)
                            }
                        }
                    } else if (isUsahaParentIncome) {
                        // If parent transaction in Usaha is opened
                        val profit = if (transaction.profitAmount > 0) transaction.profitAmount else transaction.amount
                        val pribShare = if (transaction.pribadiShareAmount > 0) transaction.pribadiShareAmount else (profit * (usahaPribadiPct / 100.0))

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                        DetailRow(
                            label = "Total Pemasukan",
                            value = CurrencyFormat.formatRupiah(transaction.amount),
                            valueWeight = FontWeight.Bold
                        )

                        if (transaction.talanganAmount > 0) {
                            DetailRow(
                                label = "Pengembalian Talangan",
                                value = CurrencyFormat.formatRupiah(transaction.talanganAmount),
                                valueColor = Color(0xFFE65100)
                            )
                        }

                        DetailRow(
                            label = "Laba Dibagi",
                            value = CurrencyFormat.formatRupiah(profit),
                            valueWeight = FontWeight.SemiBold
                        )

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = "Pembagian hasil usaha otomatis:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Text("• $usahaPribadiPct% Pribadi: ${CurrencyFormat.formatRupiah(pribShare)} ➔ Masuk Dashboard Pribadi", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                                Text("• $usahaModalPct% Modal Usaha: ${CurrencyFormat.formatRupiah(profit * (usahaModalPct / 100.0))}", fontSize = 11.sp)
                                Text("• $usahaCadanganPct% Dana Cadangan: ${CurrencyFormat.formatRupiah(profit * (usahaCadanganPct / 100.0))}", fontSize = 11.sp)
                                Text("• $usahaSedekahPct% Sedekah/Zakat: ${CurrencyFormat.formatRupiah(profit * (usahaSedekahPct / 100.0))}", fontSize = 11.sp)
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    DetailRow(
                        label = "Tanggal & Waktu",
                        value = "${transaction.dateString} • ${transaction.timeString}"
                    )

                    if (transaction.sourcePot.isNotEmpty() || !transaction.targetPot.isNullOrEmpty()) {
                        val posLabel = if (!transaction.targetPot.isNullOrEmpty()) {
                            "${transaction.sourcePot.replace("_", " ")} ➔ ${transaction.targetPot!!.replace("_", " ")}"
                        } else {
                            transaction.sourcePot.replace("_", " ")
                        }
                        DetailRow(
                            label = "Pos Dana",
                            value = posLabel
                        )
                    }

                    if (transaction.note.isNotEmpty()) {
                        DetailRow(
                            label = "Catatan",
                            value = transaction.note
                        )
                    }
                }
            }
        },
        confirmButton = {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onEdit != null) {
                    OutlinedButton(
                        onClick = {
                            onDismiss()
                            onEdit(transaction)
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_edit_transaction")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Edit")
                    }
                }

                if (onDelete != null) {
                    Button(
                        onClick = { showDeleteConfirmDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_delete_transaction")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Hapus")
                    }
                }

                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Tutup")
                }
            }
        }
    )
}

@Composable
private fun DetailRow(
    label: String,
    value: String,
    valueColor: Color = MaterialTheme.colorScheme.onSurface,
    valueWeight: FontWeight = FontWeight.Normal
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.outline,
            modifier = Modifier.weight(0.45f)
        )
        Text(
            text = value,
            fontSize = 13.sp,
            color = valueColor,
            fontWeight = valueWeight,
            modifier = Modifier.weight(0.55f)
        )
    }
}
