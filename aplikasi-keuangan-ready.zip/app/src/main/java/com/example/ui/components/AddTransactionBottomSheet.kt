package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CategoryEntity
import com.example.data.model.SystemType
import com.example.data.model.TransactionType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionBottomSheet(
    initialSystemType: SystemType,
    initialType: TransactionType = TransactionType.PENGELUARAN,
    initialProjectId: Long? = null,
    categories: List<CategoryEntity>,
    projects: List<com.example.data.model.ServiceProjectEntity> = emptyList(),
    projectSummaries: List<com.example.data.model.ProjectItemSummary> = emptyList(),
    sheetState: SheetState,
    onDismiss: () -> Unit,
    onAddCategory: ((name: String, systemType: String, txType: String) -> Unit)? = null,
    onSubmit: (
        systemType: String,
        transactionType: String,
        amount: Double,
        categoryName: String,
        dateMillis: Long,
        dateString: String,
        timeString: String,
        note: String,
        sourcePot: String,
        targetPot: String?,
        talanganAmount: Double,
        talanganPot: String,
        projectId: Long?,
        projectTitle: String?,
        isTalangan: Boolean
    ) -> Unit
) {
    var selectedSystem by remember { mutableStateOf(initialSystemType) }
    var selectedTxType by remember { mutableStateOf(initialType) }
    var amountString by remember { mutableStateOf("0") }
    var noteText by remember { mutableStateOf("") }
    var selectedProjectId by remember(initialProjectId) { mutableStateOf(initialProjectId) }
    var isAddingNewCategory by remember { mutableStateOf(false) }
    var newCategoryInput by remember { mutableStateOf("") }

    val filteredCategories = categories.filter {
        it.systemType == selectedSystem.name && it.transactionType == selectedTxType.name
    }

    var selectedCategoryName by remember(selectedSystem, selectedTxType) {
        mutableStateOf(filteredCategories.firstOrNull()?.name ?: "Umum")
    }

    // Pots selection for expense / transfer
    val pribadiPots = listOf("KEBUTUHAN", "JAJAN", "TABUNGAN", "BEBAS", "DANA_DARURAT")
    val usahaPots = listOf("MODAL_USAHA", "DANA_CADANGAN", "SEDEKAH_ZAKAT")

    var sourcePot by remember(selectedSystem) {
        mutableStateOf(if (selectedSystem == SystemType.PRIBADI) "KEBUTUHAN" else "MODAL_USAHA")
    }
    var targetPot by remember(selectedSystem) {
        mutableStateOf(if (selectedSystem == SystemType.PRIBADI) "DANA_DARURAT" else "PRIBADI")
    }

    // Is this a talangan expense?
    var isPersonalTalangan by remember(selectedSystem) { mutableStateOf(false) }

    val nowMillis = System.currentTimeMillis()
    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    val dateString = dateFormat.format(Date(nowMillis))
    val timeString = timeFormat.format(Date(nowMillis))

    val activeProjects = remember(projects) {
        projects.filter { it.status == "BERJALAN" || !it.isCompleted }
    }

    val selectedProjectSummary = remember(selectedProjectId, projectSummaries) {
        projectSummaries.firstOrNull { it.project.id == selectedProjectId }
    }
    val selectedProjectObj = remember(selectedProjectId, projects) {
        projects.firstOrNull { it.id == selectedProjectId }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Buat Transaksi",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_sheet_button")) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup")
                }
            }

            // System Selector (PRIBADI / USAHA)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (selectedSystem == SystemType.PRIBADI) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                        .clickable {
                            selectedSystem = SystemType.PRIBADI
                            isPersonalTalangan = false
                            sourcePot = "KEBUTUHAN"
                        }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "👤 PRIBADI",
                        fontWeight = FontWeight.Bold,
                        color = if (selectedSystem == SystemType.PRIBADI) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (selectedSystem == SystemType.USAHA) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                        .clickable {
                            selectedSystem = SystemType.USAHA
                            sourcePot = "MODAL_USAHA"
                        }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🌾 USAHA",
                        fontWeight = FontWeight.Bold,
                        color = if (selectedSystem == SystemType.USAHA) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // Transaction Type Selector (PEMASUKAN, PENGELUARAN, TRANSFER)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    TransactionType.PENGELUARAN to "📤 Pengeluaran",
                    TransactionType.PEMASUKAN to "📥 Pemasukan",
                    TransactionType.TRANSFER to "🔄 Transfer"
                ).forEach { (type, label) ->
                    val isSelected = selectedTxType == type
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isSelected) {
                                    when (type) {
                                        TransactionType.PEMASUKAN -> MaterialTheme.colorScheme.primaryContainer
                                        TransactionType.PENGELUARAN -> MaterialTheme.colorScheme.errorContainer
                                        TransactionType.TRANSFER -> MaterialTheme.colorScheme.secondaryContainer
                                        else -> MaterialTheme.colorScheme.tertiaryContainer
                                    }
                                } else MaterialTheme.colorScheme.surfaceContainer
                            )
                            .clickable { selectedTxType = type }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) {
                                when (type) {
                                    TransactionType.PEMASUKAN -> MaterialTheme.colorScheme.onPrimaryContainer
                                    TransactionType.PENGELUARAN -> MaterialTheme.colorScheme.onErrorContainer
                                    TransactionType.TRANSFER -> MaterialTheme.colorScheme.onSecondaryContainer
                                    else -> MaterialTheme.colorScheme.onTertiaryContainer
                                }
                            } else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Keypad for Nominal
            CalculatorKeypad(
                amountString = amountString,
                onValueChange = { amountString = it }
            )

            // If USAHA: Project Selector
            if (selectedSystem == SystemType.USAHA && activeProjects.isNotEmpty() && selectedTxType != TransactionType.TRANSFER) {
                Text(
                    text = "Hubungkan ke Project (Opsional):",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = selectedProjectId == null,
                            onClick = { selectedProjectId = null },
                            label = { Text("Tanpa Project") }
                        )
                    }
                    items(activeProjects) { proj ->
                        FilterChip(
                            selected = selectedProjectId == proj.id,
                            onClick = { selectedProjectId = proj.id },
                            label = { Text("📁 ${proj.title}") },
                            leadingIcon = if (selectedProjectId == proj.id) {
                                { Icon(Icons.Default.Check, contentDescription = null) }
                            } else null
                        )
                    }
                }
            }

            // Category Selection (For Income & Expense)
            if (selectedTxType != TransactionType.TRANSFER) {
                if (isAddingNewCategory) {
                    AlertDialog(
                        onDismissRequest = { isAddingNewCategory = false },
                        title = { Text("➕ Tambah Kategori Baru") },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "Untuk ${if (selectedSystem == SystemType.PRIBADI) "Pribadi" else "Usaha"} (${if (selectedTxType == TransactionType.PEMASUKAN) "Pemasukan" else "Pengeluaran"})",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                OutlinedTextField(
                                    value = newCategoryInput,
                                    onValueChange = { newCategoryInput = it },
                                    label = { Text("Nama Kategori") },
                                    placeholder = { Text("Misal: Bensin, Kondangan, Pupuk") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    val trimmed = newCategoryInput.trim()
                                    if (trimmed.isNotEmpty()) {
                                        onAddCategory?.invoke(trimmed, selectedSystem.name, selectedTxType.name)
                                        selectedCategoryName = trimmed
                                        isAddingNewCategory = false
                                    }
                                },
                                enabled = newCategoryInput.trim().isNotEmpty()
                            ) {
                                Text("Simpan")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { isAddingNewCategory = false }) {
                                Text("Batal")
                            }
                        }
                    )
                }

                Text(
                    text = "Kategori",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredCategories) { cat ->
                        FilterChip(
                            selected = selectedCategoryName == cat.name,
                            onClick = { selectedCategoryName = cat.name },
                            label = { Text(cat.name) },
                            leadingIcon = if (selectedCategoryName == cat.name) {
                                { Icon(Icons.Default.Check, contentDescription = null) }
                            } else null
                        )
                    }
                    item {
                        FilterChip(
                            selected = false,
                            onClick = {
                                newCategoryInput = ""
                                isAddingNewCategory = true
                            },
                            label = { Text("+ Kategori Baru") },
                            leadingIcon = {
                                Icon(
                                    Icons.Default.Add,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        )
                    }
                }
            }

            // Usaha Pemasukan with Active Talangan Notice
            if (selectedSystem == SystemType.USAHA && selectedTxType == TransactionType.PEMASUKAN) {
                if (selectedProjectSummary != null && selectedProjectSummary.activeTalangan > 0) {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "💸 Talangan Aktif Project: ${com.example.util.CurrencyFormat.formatRupiah(selectedProjectSummary.activeTalangan)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Text(
                                text = "Pemasukan ini akan otomatis mengembalikan talangan terlebih dahulu ke pos asal tanpa pembagian 50/20/20/10. Sisanya dihitung sebagai Laba Bersih Usaha.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.85f)
                            )
                        }
                    }
                }
            }

            // Pots Selection for Expense
            if (selectedTxType == TransactionType.PENGELUARAN) {
                if (selectedSystem == SystemType.USAHA) {
                    Text(
                        text = "Sumber Dana Pengeluaran:",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = !isPersonalTalangan,
                            onClick = {
                                isPersonalTalangan = false
                                sourcePot = "MODAL_USAHA"
                            },
                            label = { Text("🌾 Saldo Usaha") }
                        )
                        FilterChip(
                            selected = isPersonalTalangan,
                            onClick = {
                                isPersonalTalangan = true
                                sourcePot = "KEBUTUHAN"
                            },
                            label = { Text("👤 Talangan Pribadi") }
                        )
                    }

                    if (isPersonalTalangan) {
                        Text(
                            text = "Pilih Pos Pribadi untuk Talangan:",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(pribadiPots) { pot ->
                                FilterChip(
                                    selected = sourcePot == pot,
                                    onClick = { sourcePot = pot },
                                    label = { Text(pot.replace("_", " ")) }
                                )
                            }
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "💡 Dicatat sebagai talangan dari pos $sourcePot. Saldo $sourcePot akan berkurang sekarang dan akan otomatis dikembalikan saat ada pemasukan project.",
                                fontSize = 11.sp,
                                modifier = Modifier.padding(8.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        Text(
                            text = "Pilih Pos Usaha:",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(usahaPots) { pot ->
                                FilterChip(
                                    selected = sourcePot == pot,
                                    onClick = { sourcePot = pot },
                                    label = { Text(pot.replace("_", " ")) }
                                )
                            }
                        }
                    }
                } else {
                    Text(
                        text = "Diambil dari Pos Pribadi:",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(pribadiPots) { pot ->
                            FilterChip(
                                selected = sourcePot == pot,
                                onClick = { sourcePot = pot },
                                label = { Text(pot.replace("_", " ")) }
                            )
                        }
                    }
                }
            }

            // Pots Selection for Transfer
            if (selectedTxType == TransactionType.TRANSFER) {
                val availablePots = if (selectedSystem == SystemType.PRIBADI) pribadiPots else usahaPots

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Dari Pos:", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(availablePots) { pot ->
                            FilterChip(
                                selected = sourcePot == pot,
                                onClick = { sourcePot = pot },
                                label = { Text(pot.replace("_", " ")) }
                            )
                        }
                    }

                    Text("Ke Pos Tujuan:", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(availablePots) { pot ->
                            FilterChip(
                                selected = targetPot == pot,
                                onClick = { targetPot = pot },
                                label = { Text(pot.replace("_", " ")) }
                            )
                        }
                    }
                }
            }

            // Catatan Text Field
            OutlinedTextField(
                value = noteText,
                onValueChange = { noteText = it },
                label = { Text("Catatan (opsional)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("note_input"),
                singleLine = true
            )

            // Submit Button
            val numericAmount = amountString.filter { it.isDigit() }.toDoubleOrNull() ?: 0.0
            Button(
                onClick = {
                    if (numericAmount > 0) {
                        val finalCategory = if (selectedTxType == TransactionType.TRANSFER) "Transfer" else selectedCategoryName
                        onSubmit(
                            selectedSystem.name,
                            selectedTxType.name,
                            numericAmount,
                            finalCategory,
                            nowMillis,
                            dateString,
                            timeString,
                            noteText,
                            sourcePot,
                            if (selectedTxType == TransactionType.TRANSFER) targetPot else null,
                            0.0,
                            if (isPersonalTalangan) sourcePot else "KEBUTUHAN",
                            selectedProjectId,
                            selectedProjectObj?.title,
                            isPersonalTalangan
                        )
                        onDismiss()
                    }
                },
                enabled = numericAmount > 0,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("submit_transaction_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "SIMPAN TRANSAKSI",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
