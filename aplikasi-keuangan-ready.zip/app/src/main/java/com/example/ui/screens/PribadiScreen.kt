package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.House
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FinancialSettingsEntity
import com.example.data.model.FinanceSummary
import com.example.data.model.TransactionEntity
import com.example.ui.components.TransactionDetailDialog
import com.example.util.CurrencyFormat
import com.example.util.DateUtils

@Composable
fun PribadiScreen(
    summary: FinanceSummary,
    settings: FinancialSettingsEntity?,
    pribadiTransactions: List<TransactionEntity>,
    onOpenPiutang: () -> Unit = {},
    onEditTransaction: ((TransactionEntity) -> Unit)? = null,
    onDeleteTransaction: ((Long) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val emergencyTarget = settings?.emergencyFundTarget ?: 30000000.0
    val weeklyJajan = settings?.weeklyJajanAmount ?: 49000.0
    val kebutuhanPct = settings?.pribadiKebutuhanPct?.toInt() ?: 50
    val tabunganPct = settings?.pribadiTabunganPct?.toInt() ?: 20
    val bebasPct = settings?.pribadiBebasPct?.toInt() ?: 20
    val danaDaruratPct = settings?.pribadiDanaDaruratPct?.toInt() ?: 10

    var selectedHistoryFilter by remember { mutableStateOf("SEMUA") }
    var selectedDetailTx by remember { mutableStateOf<TransactionEntity?>(null) }

    if (selectedDetailTx != null) {
        TransactionDetailDialog(
            transaction = selectedDetailTx!!,
            settings = settings,
            onDismiss = { selectedDetailTx = null },
            onEdit = onEditTransaction,
            onDelete = onDeleteTransaction
        )
    }

    val filteredPribadiTx = remember(pribadiTransactions, selectedHistoryFilter) {
        pribadiTransactions.filter { tx ->
            val isFromUsaha = tx.originSystemType == "USAHA" ||
                    tx.note.contains("dari Usaha", ignoreCase = true) ||
                    (tx.systemType == "PRIBADI" && tx.sourcePot == "USAHA" && tx.transactionType == "PEMASUKAN")
            val isTalanganReimburse = tx.isTalanganReimbursement || tx.transactionType == "PENGEMBALIAN_TALANGAN"

            when (selectedHistoryFilter) {
                "PEMASUKAN_PRIBADI" -> tx.transactionType == "PEMASUKAN" && !isFromUsaha && !isTalanganReimburse
                "BAGIAN_USAHA" -> isFromUsaha && !isTalanganReimburse
                "PENGEMBALIAN_TALANGAN" -> isTalanganReimburse
                "PENGELUARAN" -> tx.transactionType == "PENGELUARAN"
                else -> true
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "👤 Dashboard Keuangan Pribadi",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.testTag("pribadi_dashboard_title")
            )
        }

        // Saldo Main Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_pribadi_main_balance"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(18.dp)
                ) {
                    Text(
                        text = "Total Saldo Pribadi",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = CurrencyFormat.formatRupiah(summary.totalSaldoPribadi),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Total Pemasukan", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
                            Text(
                                CurrencyFormat.formatRupiah(summary.totalPemasukanPribadi),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2E7D32)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Total Pengeluaran", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
                            Text(
                                CurrencyFormat.formatRupiah(summary.totalPengeluaranPribadi),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }

        // Piutang Pribadi Summary Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFF3E0)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Handshake, contentDescription = null, tint = Color(0xFFE65100), modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("💸 Piutang Pribadi", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                CurrencyFormat.formatRupiah(summary.totalPiutangPribadi),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Button(
                        onClick = onOpenPiutang,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Kelola", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Icon(Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // Section Title: Pembagian Pos Uang Pribadi
        item {
            Text(
                text = "Pembagian Pos Uang Pribadi",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        // Pots Grid Cards (Kebutuhan 50%, Tabungan 20%, Bebas 20%, Dana Darurat 10%)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PotCard(
                        title = "Kebutuhan ($kebutuhanPct%)",
                        amount = summary.kebutuhanBalance,
                        icon = Icons.Default.House,
                        iconBg = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    PotCard(
                        title = "Tabungan ($tabunganPct%)",
                        amount = summary.tabunganBalance,
                        icon = Icons.Default.Savings,
                        iconBg = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PotCard(
                        title = "Bebas ($bebasPct%)",
                        amount = summary.bebasBalance,
                        icon = Icons.Default.SportsEsports,
                        iconBg = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.weight(1f)
                    )
                    PotCard(
                        title = "Dana Darurat ($danaDaruratPct%)",
                        amount = summary.danaDaruratBalance,
                        icon = Icons.Default.Shield,
                        iconBg = Color(0xFFD81B60),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Special Section: 🍜 UANG JAJAN MINGGUAN
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_jajan_mingguan"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.tertiaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Fastfood,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("🍜 Uang Jajan Mingguan", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text(
                                    "Berasal dari Kebutuhan ($kebutuhanPct%) • Akumulasi tersimpan",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                    }

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp)),
                        color = MaterialTheme.colorScheme.surfaceContainer
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Saldo Jajan Tersimpan", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                Text(
                                    CurrencyFormat.formatRupiah(summary.jajanBalance),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Jatah Mingguan: ${CurrencyFormat.formatRupiah(weeklyJajan)}", fontSize = 11.sp)
                                Text(
                                    "Terpakai Hari Ini: ${CurrencyFormat.formatRupiah(summary.terpakaiJajanHariIni)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }

        // Special Section: 🛡️ DANA DARURAT TARGET
        item {
            val progress = (summary.danaDaruratBalance / emergencyTarget).coerceIn(0.0, 1.0).toFloat()
            val pct = (progress * 100).toInt()

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_dana_darurat"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = Color(0xFFD81B60),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("🛡️ Dana Darurat Target", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        Text(
                            "$pct%",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFFD81B60)
                        )
                    }

                    Text(
                        text = "${CurrencyFormat.formatRupiah(summary.danaDaruratBalance)} / ${CurrencyFormat.formatRupiah(emergencyTarget)}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp)),
                        color = Color(0xFFD81B60)
                    )
                }
            }
        }

        // Recent Transactions Pribadi with Filter
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📥 Riwayat Transaksi Pribadi",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${filteredPribadiTx.size} transaksi",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        }

        // Filter chips for Pribadi History
        item {
            val usahaPct = settings?.usahaPribadiPct?.toInt() ?: 40
            val filterOptions = listOf(
                "SEMUA" to "Semua",
                "BAGIAN_USAHA" to "🌾 $usahaPct% dari Usaha",
                "PEMASUKAN_PRIBADI" to "💰 Pemasukan Pribadi",
                "PENGEMBALIAN_TALANGAN" to "↩️ Pengembalian Talangan",
                "PENGELUARAN" to "🛒 Pengeluaran"
            )

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filterOptions) { (key, label) ->
                    FilterChip(
                        selected = selectedHistoryFilter == key,
                        onClick = { selectedHistoryFilter = key },
                        label = { Text(label, fontSize = 12.sp) }
                    )
                }
            }
        }

        if (filteredPribadiTx.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (selectedHistoryFilter != "SEMUA") "Tidak ada transaksi untuk filter ini." else "Belum ada transaksi pribadi.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }
        } else {
            val monthlyGroups = DateUtils.groupTransactionsByMonth(filteredPribadiTx)
            monthlyGroups.forEach { group ->
                item(key = "month_header_${group.monthYearTitle}") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📅 ${group.monthYearTitle}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.outlineVariant
                        )
                    }
                }
                items(group.transactions, key = { it.id }) { tx ->
                    TransactionRowItem(
                        tx = tx,
                        settings = settings,
                        onClick = { selectedDetailTx = tx }
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
fun PotCard(
    title: String,
    amount: Double,
    icon: ImageVector,
    iconBg: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(iconBg.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = iconBg, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = CurrencyFormat.formatRupiah(amount),
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

