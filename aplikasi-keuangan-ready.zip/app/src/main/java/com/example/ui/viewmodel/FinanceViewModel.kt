package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.CategoryEntity
import com.example.data.model.FinancialSettingsEntity
import com.example.data.model.FinanceSummary
import com.example.data.model.LoanEntity
import com.example.data.model.LoanRepaymentEntity
import com.example.data.model.TransactionEntity
import com.example.data.repository.FinanceRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class FinanceViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = FinanceRepository(application)

    val summary: StateFlow<FinanceSummary> = repository.summaryFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FinanceSummary())

    val settings: StateFlow<FinancialSettingsEntity?> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val transactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<CategoryEntity>> = repository.activeCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val loans: StateFlow<List<LoanEntity>> = repository.allLoansFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val projects: StateFlow<List<com.example.data.model.ServiceProjectEntity>> = repository.allProjectsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeProjects: StateFlow<List<com.example.data.model.ServiceProjectEntity>> = repository.activeProjectsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _restoreMessage = MutableStateFlow<String?>(null)
    val restoreMessage: StateFlow<String?> = _restoreMessage.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeDefaultsIfNeeded()
        }
    }

    fun addProject(
        title: String,
        customerName: String = "",
        categoryName: String = "Jasa Service",
        targetAmount: Double = 0.0,
        note: String = "",
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.addProject(
                title = title,
                customerName = customerName,
                categoryName = categoryName,
                targetAmount = targetAmount,
                note = note
            )
            onSuccess()
        }
    }

    fun updateProject(project: com.example.data.model.ServiceProjectEntity) {
        viewModelScope.launch {
            repository.updateProject(project)
        }
    }

    fun updateProjectStatus(id: Long, status: String) {
        viewModelScope.launch {
            repository.updateProjectStatus(id, status)
        }
    }

    fun deleteProject(id: Long) {
        viewModelScope.launch {
            repository.deleteProject(id)
        }
    }

    fun getRepaymentsFlow(loanId: Long): Flow<List<LoanRepaymentEntity>> {
        return repository.getRepaymentsFlow(loanId)
    }

    fun addLoan(
        borrowerName: String,
        amount: Double,
        dateMillis: Long,
        dateString: String,
        dueDateString: String,
        note: String,
        systemType: String,
        sourcePot: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.addLoan(
                borrowerName = borrowerName,
                amount = amount,
                dateMillis = dateMillis,
                dateString = dateString,
                dueDateString = dueDateString,
                note = note,
                systemType = systemType,
                sourcePot = sourcePot
            )
            onSuccess()
        }
    }

    fun addRepayment(
        loanId: Long,
        repaymentAmount: Double,
        dateMillis: Long,
        dateString: String,
        timeString: String,
        note: String,
        targetPot: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.addRepayment(
                loanId = loanId,
                repaymentAmount = repaymentAmount,
                dateMillis = dateMillis,
                dateString = dateString,
                timeString = timeString,
                note = note,
                targetPot = targetPot
            )
            if (result.isSuccess) {
                onResult(true, null)
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "Gagal menambah pengembalian.")
            }
        }
    }

    fun deleteLoan(id: Long) {
        viewModelScope.launch {
            repository.deleteLoan(id)
        }
    }

    fun refreshWeeklyJajan() {
        viewModelScope.launch {
            repository.processWeeklyJajanIfNeeded()
        }
    }

    fun refreshDailyJajan() {
        refreshWeeklyJajan()
    }

    fun repayTalangan(
        projectId: Long,
        repaymentAmount: Double,
        sourceUsahaPot: String = "MODAL_USAHA",
        targetPersonalPot: String = "KEBUTUHAN",
        note: String = "",
        onResult: (Boolean, String?) -> Unit = { _, _ -> }
    ) {
        viewModelScope.launch {
            val res = repository.repayTalangan(
                projectId = projectId,
                repaymentAmount = repaymentAmount,
                sourceUsahaPot = sourceUsahaPot,
                targetPersonalPot = targetPersonalPot,
                note = note
            )
            if (res.isSuccess) {
                onResult(true, null)
            } else {
                onResult(false, res.exceptionOrNull()?.message ?: "Gagal memproses pengembalian talangan")
            }
        }
    }

    fun addTransaction(
        systemType: String,
        transactionType: String,
        amount: Double,
        categoryName: String,
        dateMillis: Long,
        dateString: String,
        timeString: String,
        note: String,
        sourcePot: String,
        targetPot: String? = null,
        talanganAmount: Double = 0.0,
        talanganPot: String = "KEBUTUHAN",
        projectId: Long? = null,
        projectTitle: String? = null,
        isTalangan: Boolean = false
    ) {
        viewModelScope.launch {
            repository.addTransaction(
                systemType = systemType,
                transactionType = transactionType,
                amount = amount,
                categoryName = categoryName,
                dateMillis = dateMillis,
                dateString = dateString,
                timeString = timeString,
                note = note,
                sourcePot = sourcePot,
                targetPot = targetPot,
                talanganAmount = talanganAmount,
                talanganPot = talanganPot,
                projectId = projectId,
                projectTitle = projectTitle,
                isTalangan = isTalangan
            )
        }
    }

    fun deleteTransaction(id: Long) {
        viewModelScope.launch {
            repository.deleteTransaction(id)
        }
    }

    fun updateTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.updateTransaction(transaction)
        }
    }

    fun updateSettings(settings: FinancialSettingsEntity) {
        viewModelScope.launch {
            repository.updateSettings(settings)
        }
    }

    fun addCategory(category: CategoryEntity) {
        viewModelScope.launch {
            repository.addCategory(category)
        }
    }

    fun addCategory(name: String, systemType: String, txType: String) {
        viewModelScope.launch {
            repository.addCategory(
                CategoryEntity(
                    name = name,
                    systemType = systemType,
                    transactionType = txType,
                    isDefault = false
                )
            )
        }
    }

    fun updateCategory(category: CategoryEntity) {
        viewModelScope.launch {
            repository.updateCategory(category)
        }
    }

    fun archiveCategory(id: Long) {
        viewModelScope.launch {
            repository.archiveCategory(id)
        }
    }

    fun exportBackup(onResult: (String) -> Unit) {
        viewModelScope.launch {
            val json = repository.exportBackupJson()
            onResult(json)
        }
    }

    fun restoreBackup(jsonString: String) {
        viewModelScope.launch {
            val success = repository.restoreBackupJson(jsonString)
            if (success) {
                _restoreMessage.value = "Data berhasil dipulihkan!"
            } else {
                _restoreMessage.value = "Gagal memulihkan data. Format file tidak valid."
            }
        }
    }

    fun clearRestoreMessage() {
        _restoreMessage.value = null
    }
}
