package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FinancialSettingsEntity
import com.example.data.model.FinanceSummary
import com.example.data.model.TransactionEntity
import com.example.ui.components.TransactionDetailDialog
import com.example.util.CurrencyFormat
import com.example.util.DateUtils

@Composable
fun BerandaScreen(
    summary: FinanceSummary,
    settings: FinancialSettingsEntity?,
    recentTransactions: List<TransactionEntity>,
    onOpenPiutang: () -> Unit = {},
    onEditTransaction: ((TransactionEntity) -> Unit)? = null,
    onDeleteTransaction: ((Long) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val emergencyTarget = settings?.emergencyFundTarget ?: 30000000.0
    val weeklyJajan = settings?.weeklyJajanAmount ?: 49000.0
    val enableDueNotif = settings?.enableDueNotification ?: true

    var selectedDetailTx by remember { mutableStateOf<TransactionEntity?>(null) }

    if (selectedDetailTx != null) {
        TransactionDetailDialog(
            transaction = selectedDetailTx!!,
            settings = settings,
            onDismiss = { selectedDetailTx = null },
            onEdit = onEditTransaction,
            onDelete = onDeleteTransaction
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Ringkasan Keuangan",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.testTag("beranda_title")
            )
        }

        // Notification Banner for Overdue Loans
        if (enableDueNotif && summary.overdueLoansCount > 0) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("due_notification_banner"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = null,
                            tint = Color(0xFFC62828),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "🔔 Pinjaman Jatuh Tempo",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFFC62828)
                            )
                            Text(
                                text = "Ada ${summary.overdueLoansCount} pinjaman yang sudah melewati batas waktu pembayaran.",
                                fontSize = 11.sp,
                                color = Color(0xFFB71C1C)
                            )
                        }
                        OutlinedButton(
                            onClick = onOpenPiutang,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFC62828))
                        ) {
                            Text("Cek", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // HERO CARD: Uang Jajan Mingguan (Fokus Visual Paling Utama)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hero_card_uang_jajan"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.35f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    // Header Row: Label + Week Badge
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Fastfood,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "🍜 UANG JAJAN MINGGUAN",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 0.5.sp,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                                Text(
                                    text = "Sisa saldo siap digunakan",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.75f)
                                )
                            }
                        }

                        // Periode Minggu Berjalan
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
                        ) {
                            Text(
                                text = DateUtils.getCurrentWeekDisplay(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Nominal Saldo Uang Jajan (Sangat Besar & Paling Menonjol)
                    val displayJajanBalance = summary.jajanBalance.coerceAtLeast(0.0)
                    Text(
                        text = CurrencyFormat.formatRupiah(displayJajanBalance),
                        fontSize = 34.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.testTag("hero_jajan_balance_amount")
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Catatan Akumulasi / Status Rp0
                    if (summary.jajanBalance > 0.0) {
                        Text(
                            text = "✨ Termasuk akumulasi sisa minggu lalu",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.85f)
                        )
                    } else {
                        Text(
                            text = "⚠️ Saldo jajan Rp 0 (pos Kebutuhan habis / belum ada alokasi)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.error
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Informasi Pendukung: Jatah & Terpakai
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Jatah:",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = CurrencyFormat.formatRupiah(weeklyJajan),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Terpakai:",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = CurrencyFormat.formatRupiah(summary.terpakaiJajanHariIni),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }

        // Card Balance Overview (Pribadi & Usaha - Hierarki Lebih Kecil)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Saldo Pribadi
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_saldo_pribadi"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "👤 Saldo Pribadi",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = CurrencyFormat.formatRupiah(summary.totalSaldoPribadi),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                // Saldo Usaha
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_saldo_usaha"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Store,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                                tint = MaterialTheme.colorScheme.secondary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "🌾 Saldo Usaha",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = CurrencyFormat.formatRupiah(summary.totalSaldoUsaha),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }
        }

        // Piutang Card (Uang Dipinjamkan)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("piutang_summary_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFFF3E0)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Handshake,
                                    contentDescription = null,
                                    tint = Color(0xFFE65100),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("💸 Uang Dipinjamkan", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(
                                    "${summary.unpaidLoansCount} orang lum lunas${if (summary.overdueLoansCount > 0) " • ${summary.overdueLoansCount} jatuh tempo" else ""}",
                                    fontSize = 11.sp,
                                    color = if (summary.overdueLoansCount > 0) Color(0xFFC62828) else MaterialTheme.colorScheme.outline
                                )
                            }
                        }

                        Button(
                            onClick = onOpenPiutang,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("lihat_piutang_button")
                        ) {
                            Text("Kelola", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total Piutang Aktif", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                            Text(
                                CurrencyFormat.formatRupiah(summary.totalPiutang),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("👤 ${CurrencyFormat.formatRupiah(summary.totalPiutangPribadi)}", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Text("🌾 ${CurrencyFormat.formatRupiah(summary.totalPiutangUsaha)}", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }

        // Quick Stats: Dana Darurat & Tabungan
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Dana Darurat Progress
                    val progress = (summary.danaDaruratBalance / emergencyTarget).coerceIn(0.0, 1.0).toFloat()
                    val pct = (progress * 100).toInt()
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("🛡️ Dana Darurat", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Text(
                                "${CurrencyFormat.formatRupiah(summary.danaDaruratBalance)} / ${CurrencyFormat.formatRupiah(emergencyTarget)} ($pct%)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp),
                        color = MaterialTheme.colorScheme.outlineVariant
                    ) {}

                    // Tabungan
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Savings,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("💰 Total Tabungan", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Text(
                            CurrencyFormat.formatRupiah(summary.tabunganBalance),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }
        }

        // Summary Income & Expense Card
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Total Income
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF2E7D32)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Pemasukan", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                            Text(
                                CurrencyFormat.formatRupiah(summary.totalPemasukanPribadi + summary.totalPemasukanUsaha),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2E7D32)
                            )
                        }
                    }
                }

                // Total Expense
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.error),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Pengeluaran", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                            Text(
                                CurrencyFormat.formatRupiah(summary.totalPengeluaranPribadi + summary.totalPengeluaranUsaha),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }

        // Recent Transactions Section Header
        item {
            Text(
                text = "Transaksi Terbaru",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        if (recentTransactions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Belum ada transaksi recorded.\nTekan + untuk membuat transaksi baru.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        } else {
            val monthlyGroups = DateUtils.groupTransactionsByMonth(recentTransactions.take(10))
            monthlyGroups.forEach { group ->
                item(key = "beranda_month_header_${group.monthYearTitle}") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📅 ${group.monthYearTitle}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.outlineVariant
                        )
                    }
                }
                items(group.transactions, key = { it.id }) { tx ->
                    TransactionRowItem(
                        tx = tx,
                        settings = settings,
                        onClick = { selectedDetailTx = tx }
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
fun TransactionRowItem(
    tx: TransactionEntity,
    settings: FinancialSettingsEntity? = null,
    onClick: () -> Unit = {}
) {
    val isFromUsaha = tx.originSystemType == "USAHA" ||
            tx.note.contains("dari Usaha", ignoreCase = true) ||
            (tx.systemType == "PRIBADI" && tx.sourcePot == "USAHA" && tx.transactionType == "PEMASUKAN")

    val isTalanganReimburse = tx.isTalanganReimbursement ||
            tx.transactionType == "PENGEMBALIAN_TALANGAN"

    val usahaPct = settings?.usahaPribadiPct?.toInt() ?: 40

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        tonalElevation = 1.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val iconBg = when {
                    isTalanganReimburse -> Color(0xFFE8F5E9)
                    isFromUsaha -> Color(0xFFE3F2FD)
                    tx.transactionType == "PEMASUKAN" -> Color(0xFFE8F5E9)
                    tx.transactionType == "PENGELUARAN" || tx.transactionType == "PINJAMAN" -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
                    else -> MaterialTheme.colorScheme.secondaryContainer
                }
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    val emoji = when {
                        isTalanganReimburse -> "↩️"
                        isFromUsaha -> {
                            val cat = tx.sourceCategoryName?.lowercase() ?: tx.categoryName.lowercase()
                            when {
                                cat.contains("panen") || cat.contains("tani") || cat.contains("cabai") || cat.contains("cabe") -> "🌶️"
                                cat.contains("servis") || cat.contains("service") || cat.contains("jasa") -> "🔧"
                                cat.contains("sampingan") -> "💼"
                                else -> "🌾"
                            }
                        }
                        tx.systemType == "PRIBADI" -> {
                            val cat = tx.categoryName.lowercase()
                            when {
                                cat.contains("gaji") -> "💵"
                                cat.contains("makan") || cat.contains("kuliner") || cat.contains("jajan") -> "🍔"
                                cat.contains("transport") || cat.contains("bensin") -> "⛽"
                                else -> "👤"
                            }
                        }
                        else -> "🌾"
                    }
                    Text(
                        text = emoji,
                        fontSize = 17.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    val displayCategory = if (isFromUsaha && !tx.sourceCategoryName.isNullOrBlank()) {
                        tx.sourceCategoryName
                    } else {
                        tx.categoryName
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = displayCategory,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    if (isFromUsaha) {
                        Surface(
                            color = Color(0xFFE8F5E9),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.padding(top = 2.dp, bottom = 2.dp)
                        ) {
                            Text(
                                text = "$usahaPct% dari Usaha",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2E7D32),
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    } else if (isTalanganReimburse) {
                        Surface(
                            color = Color(0xFFFFF3E0),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.padding(top = 2.dp, bottom = 2.dp)
                        ) {
                            Text(
                                text = "↩️ Bukan pendapatan baru",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFFE65100),
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }

                    if (!tx.projectTitle.isNullOrEmpty()) {
                        Text(
                            text = "Project: ${tx.projectTitle}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Text(
                        text = "${tx.dateString} ${tx.timeString}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            val prefix = when (tx.transactionType) {
                "PEMASUKAN", "PENGEMBALIAN", "PENGEMBALIAN_TALANGAN" -> "+"
                "PENGELUARAN", "PINJAMAN" -> "-"
                else -> "🔄"
            }
            val color = when (tx.transactionType) {
                "PEMASUKAN", "PENGEMBALIAN", "PENGEMBALIAN_TALANGAN" -> Color(0xFF2E7D32)
                "PENGELUARAN", "PINJAMAN" -> MaterialTheme.colorScheme.error
                else -> MaterialTheme.colorScheme.secondary
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "$prefix ${CurrencyFormat.formatRupiah(tx.amount)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = color
                )
                if (isTalanganReimburse && !tx.targetPot.isNullOrEmpty()) {
                    Text(
                        text = "Masuk: ${tx.targetPot.replace("_", " ")}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                } else if (tx.sourcePot.isNotEmpty() && tx.systemType == "PRIBADI" && !isFromUsaha) {
                    Text(
                        text = "Pos: ${tx.sourcePot.replace("_", " ")}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        }
    }
}
