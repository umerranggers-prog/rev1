package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FinancialSettingsEntity
import com.example.data.model.TransactionEntity
import com.example.ui.components.TransactionDetailDialog
import com.example.util.CurrencyFormat

@Composable
fun RiwayatTransaksiScreen(
    transactions: List<TransactionEntity>,
    onDeleteTransaction: (Long) -> Unit,
    onEditTransaction: ((TransactionEntity) -> Unit)? = null,
    settings: FinancialSettingsEntity? = null,
    modifier: Modifier = Modifier
) {
    var selectedSystemFilter by remember { mutableStateOf("SEMUA") } // SEMUA, PRIBADI, USAHA
    var selectedTypeFilter by remember { mutableStateOf("SEMUA") } // SEMUA, PEMASUKAN, 40% DARI USAHA, PENGEMBALIAN TALANGAN, PENGELUARAN, TRANSFER
    var searchQuery by remember { mutableStateOf("") }

    var transactionToDelete by remember { mutableStateOf<TransactionEntity?>(null) }
    var selectedDetailTx by remember { mutableStateOf<TransactionEntity?>(null) }

    val usahaPct = settings?.usahaPribadiPct?.toInt() ?: 40

    val filteredList = remember(transactions, selectedSystemFilter, selectedTypeFilter, searchQuery) {
        transactions.filter { tx ->
            val isFromUsaha = tx.originSystemType == "USAHA" ||
                    tx.note.contains("dari Usaha", ignoreCase = true) ||
                    (tx.systemType == "PRIBADI" && tx.sourcePot == "USAHA" && tx.transactionType == "PEMASUKAN")
            val isTalanganReimburse = tx.isTalanganReimbursement || tx.transactionType == "PENGEMBALIAN_TALANGAN"

            val matchSystem = if (selectedSystemFilter == "SEMUA") true else tx.systemType == selectedSystemFilter
            val matchType = when (selectedTypeFilter) {
                "SEMUA" -> true
                "40% DARI USAHA" -> isFromUsaha && !isTalanganReimburse
                "PENGEMBALIAN TALANGAN" -> isTalanganReimburse
                else -> tx.transactionType == selectedTypeFilter
            }
            val matchQuery = if (searchQuery.isBlank()) true else {
                tx.categoryName.contains(searchQuery, ignoreCase = true) ||
                        (tx.sourceCategoryName?.contains(searchQuery, ignoreCase = true) ?: false) ||
                        (tx.projectTitle?.contains(searchQuery, ignoreCase = true) ?: false) ||
                        tx.note.contains(searchQuery, ignoreCase = true)
            }
            matchSystem && matchType && matchQuery
        }
    }

    if (selectedDetailTx != null) {
        TransactionDetailDialog(
            transaction = selectedDetailTx!!,
            settings = settings,
            onDismiss = { selectedDetailTx = null },
            onEdit = onEditTransaction,
            onDelete = onDeleteTransaction
        )
    }

    if (transactionToDelete != null) {
        AlertDialog(
            onDismissRequest = { transactionToDelete = null },
            title = { Text("Hapus Transaksi?") },
            text = { Text("Apakah Anda yakin ingin menghapus transaksi '${transactionToDelete?.categoryName}'?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        transactionToDelete?.let { onDeleteTransaction(it.id) }
                        transactionToDelete = null
                    }
                ) {
                    Text("Hapus", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { transactionToDelete = null }) {
                    Text("Batal")
                }
            }
        )
    }

    val monthlyGroups = remember(filteredList) {
        com.example.util.DateUtils.groupTransactionsByMonth(filteredList)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "📜 Riwayat Transaksi",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.testTag("riwayat_title")
            )
        }

        // Search Field
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Cari kategori, project, atau catatan...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_history_input"),
                singleLine = true
            )
        }

        // Filters: System Type
        item {
            Text("Sistem:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("SEMUA", "PRIBADI", "USAHA")) { sys ->
                    FilterChip(
                        selected = selectedSystemFilter == sys,
                        onClick = { selectedSystemFilter = sys },
                        label = { Text(sys) }
                    )
                }
            }
        }

        // Filters: Transaction Type
        item {
            Text("Jenis Transaksi:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            val typeList = listOf(
                "SEMUA" to "Semua",
                "PEMASUKAN" to "Pemasukan",
                "40% DARI USAHA" to "🌾 $usahaPct% dari Usaha",
                "PENGEMBALIAN TALANGAN" to "↩️ Pengembalian Talangan",
                "PENGELUARAN" to "Pengeluaran",
                "TRANSFER" to "Transfer"
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(typeList) { (key, label) ->
                    FilterChip(
                        selected = selectedTypeFilter == key,
                        onClick = { selectedTypeFilter = key },
                        label = { Text(label) }
                    )
                }
            }
        }

        // Monthly Grouped Transaction List
        if (monthlyGroups.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Tidak ada transaksi ditemukan.", color = MaterialTheme.colorScheme.outline)
                }
            }
        } else {
            monthlyGroups.forEachIndexed { groupIndex, group ->
                // Month Header
                item(key = "header_${group.key}") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = if (groupIndex > 0) 14.dp else 4.dp, bottom = 4.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "📅 ${group.monthYearTitle}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    }
                }

                // Items in this month
                items(group.transactions, key = { it.id }) { tx ->
                    val isFromUsaha = tx.originSystemType == "USAHA" ||
                            tx.note.contains("dari Usaha", ignoreCase = true) ||
                            (tx.systemType == "PRIBADI" && tx.sourcePot == "USAHA" && tx.transactionType == "PEMASUKAN")
                    val isTalanganReimburse = tx.isTalanganReimbursement || tx.transactionType == "PENGEMBALIAN_TALANGAN"
                    val dayMonthDisplay = com.example.util.DateUtils.formatDayMonth(tx.dateString, tx.dateMillis)

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedDetailTx = tx },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainer
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = if (tx.systemType == "PRIBADI") "👤 Pribadi" else "🌾 Usaha",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(" • $dayMonthDisplay • ${tx.timeString}", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                val displayCategory = if (isFromUsaha && !tx.sourceCategoryName.isNullOrBlank()) {
                                    tx.sourceCategoryName
                                } else {
                                    tx.categoryName
                                }
                                Text(
                                    text = displayCategory,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )

                                if (isFromUsaha) {
                                    Surface(
                                        color = Color(0xFFE8F5E9),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.padding(top = 2.dp, bottom = 2.dp)
                                    ) {
                                        Text(
                                            text = "$usahaPct% dari Usaha",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF2E7D32),
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                } else if (isTalanganReimburse) {
                                    Surface(
                                        color = Color(0xFFFFF3E0),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.padding(top = 2.dp, bottom = 2.dp)
                                    ) {
                                        Text(
                                            text = "↩️ Pengembalian Talangan",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFFE65100),
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }

                                if (!tx.projectTitle.isNullOrEmpty()) {
                                    Text(
                                        text = "📁 Project: ${tx.projectTitle}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                if (tx.note.isNotEmpty()) {
                                    Text(
                                        text = tx.note,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(horizontalAlignment = Alignment.End) {
                                    val color = when (tx.transactionType) {
                                        "PEMASUKAN", "PENGEMBALIAN", "PENGEMBALIAN_TALANGAN" -> Color(0xFF2E7D32)
                                        "PENGELUARAN", "PINJAMAN" -> MaterialTheme.colorScheme.error
                                        else -> MaterialTheme.colorScheme.secondary
                                    }
                                    val prefix = when (tx.transactionType) {
                                        "PEMASUKAN", "PENGEMBALIAN", "PENGEMBALIAN_TALANGAN" -> "+"
                                        "PENGELUARAN", "PINJAMAN" -> "-"
                                        else -> "🔄"
                                    }
                                    Text(
                                        text = "$prefix ${CurrencyFormat.formatRupiah(tx.amount)}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = color
                                    )
                                    Text(
                                        text = when {
                                            isTalanganReimburse -> "Talangan Kembali"
                                            isFromUsaha -> "$usahaPct% dari Usaha"
                                            else -> tx.transactionType
                                        },
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }

                                IconButton(onClick = { transactionToDelete = tx }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Hapus",
                                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f)
                                    )
                                }
                            }
                        }
                    }
                }

                // Month Divider
                if (groupIndex < monthlyGroups.size - 1) {
                    item(key = "divider_${group.key}") {
                        androidx.compose.material3.HorizontalDivider(
                            modifier = Modifier.padding(vertical = 10.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

