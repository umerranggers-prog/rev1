package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FinanceSummary
import com.example.data.model.FinancialSettingsEntity
import com.example.data.model.ProjectItemSummary
import com.example.data.model.TransactionEntity
import com.example.util.CurrencyFormat
import com.example.util.DateUtils

@Composable
fun UsahaScreen(
    summary: FinanceSummary,
    settings: FinancialSettingsEntity?,
    usahaTransactions: List<TransactionEntity>,
    onOpenPiutang: () -> Unit = {},
    onAddProject: (title: String, customer: String, category: String, target: Double, note: String) -> Unit = { _, _, _, _, _ -> },
    onUpdateProjectStatus: (id: Long, status: String) -> Unit = { _, _ -> },
    onDeleteProject: (id: Long) -> Unit = {},
    onQuickTransaction: (projectId: Long, projectTitle: String, isExpense: Boolean) -> Unit = { _, _, _ -> },
    onRepayTalangan: ((projectId: Long, amount: Double, sourceUsahaPot: String, targetPersonalPot: String, note: String) -> Unit)? = null,
    onEditTransaction: ((TransactionEntity) -> Unit)? = null,
    onDeleteTransaction: ((Long) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val usahaPribadiPct = settings?.usahaPribadiPct?.toInt() ?: 40
    val usahaModalPct = settings?.usahaModalPct?.toInt() ?: 30
    val usahaCadanganPct = settings?.usahaCadanganPct?.toInt() ?: 20
    val usahaSedekahPct = settings?.usahaSedekahPct?.toInt() ?: 10

    var isAddProjectDialogOpen by remember { mutableStateOf(false) }
    var projectStatusFilter by remember { mutableStateOf("SEMUA") } // SEMUA, BERJALAN, SELESAI
    var projectToDelete by remember { mutableStateOf<ProjectItemSummary?>(null) }
    var projectForRepayment by remember { mutableStateOf<ProjectItemSummary?>(null) }
    var selectedDetailTx by remember { mutableStateOf<TransactionEntity?>(null) }

    if (selectedDetailTx != null) {
        com.example.ui.components.TransactionDetailDialog(
            transaction = selectedDetailTx!!,
            settings = settings,
            onDismiss = { selectedDetailTx = null },
            onEdit = onEditTransaction,
            onDelete = onDeleteTransaction
        )
    }

    val filteredProjects = remember(summary.projectSummaries, projectStatusFilter) {
        when (projectStatusFilter) {
            "BERJALAN" -> summary.projectSummaries.filter { it.project.status == "BERJALAN" || !it.project.isCompleted }
            "SELESAI" -> summary.projectSummaries.filter { it.project.status == "SELESAI" || it.project.isCompleted }
            else -> summary.projectSummaries
        }
    }

    if (isAddProjectDialogOpen) {
        AddProjectDialog(
            onDismiss = { isAddProjectDialogOpen = false },
            onSubmit = { title, customer, category, target, note ->
                onAddProject(title, customer, category, target, note)
                isAddProjectDialogOpen = false
            }
        )
    }

    if (projectToDelete != null) {
        AlertDialog(
            onDismissRequest = { projectToDelete = null },
            title = { Text("Hapus Project?") },
            text = { Text("Apakah Anda yakin ingin menghapus project '${projectToDelete?.project?.title}'? Riwayat transaksi project tetap tersimpan.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        projectToDelete?.let { onDeleteProject(it.project.id) }
                        projectToDelete = null
                    }
                ) {
                    Text("Hapus", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { projectToDelete = null }) {
                    Text("Batal")
                }
            }
        )
    }

    if (projectForRepayment != null) {
        RepayTalanganDialog(
            summary = projectForRepayment!!,
            onDismiss = { projectForRepayment = null },
            onSubmit = { amount, sourceUsahaPot, targetPersonalPot, note ->
                projectForRepayment?.let { p ->
                    onRepayTalangan?.invoke(p.project.id, amount, sourceUsahaPot, targetPersonalPot, note)
                }
                projectForRepayment = null
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "🌾 Dashboard Keuangan Usaha",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.testTag("usaha_dashboard_title")
            )
        }

        // Main Saldo Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_usaha_main_balance"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(18.dp)
                ) {
                    Text(
                        text = "Total Saldo Usaha",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = CurrencyFormat.formatRupiah(summary.totalSaldoUsaha),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Total Pemasukan", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f))
                            Text(
                                CurrencyFormat.formatRupiah(summary.totalPemasukanUsaha),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2E7D32)
                            )
                        }
                        Column {
                            Text("Total Pengeluaran", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f))
                            Text(
                                CurrencyFormat.formatRupiah(summary.totalPengeluaranUsaha),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Laba Usaha", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f))
                            Text(
                                CurrencyFormat.formatRupiah(summary.labaUsaha),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (summary.labaUsaha >= 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }

        // Piutang Usaha Summary Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFF3E0)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Handshake, contentDescription = null, tint = Color(0xFFE65100), modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("🌾 Piutang Usaha", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                CurrencyFormat.formatRupiah(summary.totalPiutangUsaha),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Button(
                        onClick = onOpenPiutang,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Kelola", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Icon(Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // Active Talangan Banner
        if (summary.activeTalanganCount > 0) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("⚠️", fontSize = 20.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Talangan Aktif (${summary.activeTalanganCount} Project)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.error
                            )
                            Text(
                                text = "Total dana talangan belum kembali: ${CurrencyFormat.formatRupiah(summary.totalActiveTalangan)}. Akan otomatis diganti saat project menerima pemasukan.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // SECTION: SYSTEM PROJECT USAHA
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "📁 Project Usaha",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Kelola proyek, talangan & laba terpisah",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                Button(
                    onClick = { isAddProjectDialogOpen = true },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Tambah Project", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Filter chips for projects
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("SEMUA", "BERJALAN", "SELESAI")) { status ->
                    FilterChip(
                        selected = projectStatusFilter == status,
                        onClick = { projectStatusFilter = status },
                        label = {
                            Text(
                                when (status) {
                                    "BERJALAN" -> "⚡ Berjalan"
                                    "SELESAI" -> "✅ Selesai"
                                    else -> "Semua (${summary.projectSummaries.size})"
                                }
                            )
                        }
                    )
                }
            }
        }

        // Project Items List
        if (filteredProjects.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Belum ada project ${if (projectStatusFilter != "SEMUA") projectStatusFilter.lowercase() else ""}.", fontSize = 13.sp, color = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(6.dp))
                        TextButton(onClick = { isAddProjectDialogOpen = true }) {
                            Text("+ Buat Project Baru Sekarang")
                        }
                    }
                }
            }
        } else {
            items(filteredProjects) { pSummary ->
                ProjectSummaryCard(
                    summary = pSummary,
                    onStatusChange = { newStatus -> onUpdateProjectStatus(pSummary.project.id, newStatus) },
                    onDelete = { projectToDelete = pSummary },
                    onAddExpense = { onQuickTransaction(pSummary.project.id, pSummary.project.title, true) },
                    onAddIncome = { onQuickTransaction(pSummary.project.id, pSummary.project.title, false) },
                    onRepayTalangan = { projectForRepayment = pSummary }
                )
            }
        }

        // Section Title: Pos Alokasi Usaha
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Pos Alokasi Usaha",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        // Cards for Modal Usaha, Dana Cadangan, Sedekah/Zakat
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PotCard(
                        title = "Modal Usaha ($usahaModalPct%)",
                        amount = summary.modalUsahaBalance,
                        icon = Icons.Default.MonetizationOn,
                        iconBg = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.weight(1f)
                    )
                    PotCard(
                        title = "Dana Cadangan ($usahaCadanganPct%)",
                        amount = summary.cadanganUsahaBalance,
                        icon = Icons.Default.AccountBalance,
                        iconBg = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PotCard(
                        title = "Sedekah/Zakat ($usahaSedekahPct%)",
                        amount = summary.sedekahUsahaBalance,
                        icon = Icons.Default.VolunteerActivism,
                        iconBg = Color(0xFF2E7D32),
                        modifier = Modifier.weight(1f)
                    )

                    // Card Info Auto Split to Pribadi
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    "Ke Pribadi ($usahaPribadiPct%)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "Otomatis masuk ke Saldo Pribadi saat ada Pemasukan Usaha",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Recent Transactions Usaha
        item {
            Text(
                text = "Riwayat Transaksi Usaha",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        if (usahaTransactions.isEmpty()) {
            item {
                Text(
                    text = "Belum ada transaksi usaha.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        } else {
            val monthlyGroups = DateUtils.groupTransactionsByMonth(usahaTransactions)
            monthlyGroups.forEach { group ->
                item(key = "usaha_month_header_${group.monthYearTitle}") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📅 ${group.monthYearTitle}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.outlineVariant
                        )
                    }
                }
                items(group.transactions, key = { it.id }) { tx ->
                    TransactionRowItem(
                        tx = tx,
                        settings = settings,
                        onClick = { selectedDetailTx = tx }
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
fun ProjectSummaryCard(
    summary: ProjectItemSummary,
    onStatusChange: (String) -> Unit,
    onDelete: () -> Unit,
    onAddExpense: () -> Unit,
    onAddIncome: () -> Unit,
    onRepayTalangan: (() -> Unit)? = null
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val isCompleted = summary.project.status == "SELESAI" || summary.project.isCompleted

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header: Title, Category, Status & Menu
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = if (isCompleted) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = if (isCompleted) "✅ Selesai" else "⚡ Berjalan",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isCompleted) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        if (summary.project.categoryName.isNotEmpty()) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "• ${summary.project.categoryName}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = summary.project.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (summary.project.customerName.isNotEmpty()) {
                        Text(
                            text = "Klien: ${summary.project.customerName}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Box {
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Menu Project")
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        if (!isCompleted) {
                            DropdownMenuItem(
                                text = { Text("Tandai Selesai") },
                                leadingIcon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32)) },
                                onClick = {
                                    onStatusChange("SELESAI")
                                    menuExpanded = false
                                }
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text("Buka Kembali Project") },
                                leadingIcon = { Icon(Icons.Default.Replay, contentDescription = null) },
                                onClick = {
                                    onStatusChange("BERJALAN")
                                    menuExpanded = false
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Hapus Project", color = MaterialTheme.colorScheme.error) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                            onClick = {
                                menuExpanded = false
                                onDelete()
                            }
                        )
                    }
                }
            }

            // Metrics Grid (Pemasukan, Pengeluaran, Talangan, Laba)
            Surface(
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Pemasukan", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                            Text(
                                CurrencyFormat.formatRupiah(summary.totalIncome),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2E7D32)
                            )
                        }
                        Column {
                            Text("Pengeluaran", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                            Text(
                                CurrencyFormat.formatRupiah(summary.totalExpense),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Laba Bersih", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                            Text(
                                CurrencyFormat.formatRupiah(summary.laba),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (summary.laba >= 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    if (summary.totalTalangan > 0) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Dana Talangan: ${CurrencyFormat.formatRupiah(summary.totalTalangan)}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (summary.activeTalangan > 0.01) {
                                Surface(
                                    color = MaterialTheme.colorScheme.errorContainer,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "Sisa Talangan: ${CurrencyFormat.formatRupiah(summary.activeTalangan)}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            } else {
                                Text(
                                    text = "Talangan Lunas ✅",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32)
                                )
                            }
                        }
                    }
                }
            }

            if (summary.activeTalangan > 0.01) {
                Button(
                    onClick = { onRepayTalangan?.invoke() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("↩️ Kembalikan / Lunasi Talangan", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Quick Transaction Buttons for this Project
            if (!isCompleted) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onAddExpense,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("- Biaya Project", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Button(
                        onClick = onAddIncome,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("+ Pemasukan", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
fun AddProjectDialog(
    onDismiss: () -> Unit,
    onSubmit: (title: String, customer: String, category: String, target: Double, note: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var customer by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Jasa Service") }
    var targetStr by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    val defaultCategories = listOf("Jasa Service", "Pertanian", "Konveksi", "Perdagangan", "Proyek", "Lainnya")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("➕ Tambah Project Usaha") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Nama Project *") },
                    placeholder = { Text("Contoh: Service TV Andi, Panen Cabai") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = customer,
                    onValueChange = { customer = it },
                    label = { Text("Nama Pelanggan / Klien (opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Kategori Project:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(defaultCategories) { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 12.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = targetStr,
                    onValueChange = { targetStr = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Target / Estimasi Nilai Rp (opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Catatan Project (opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val targetVal = targetStr.toDoubleOrNull() ?: 0.0
                        onSubmit(title.trim(), customer.trim(), category, targetVal, note.trim())
                    }
                },
                enabled = title.isNotBlank()
            ) {
                Text("Simpan Project")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
fun RepayTalanganDialog(
    summary: ProjectItemSummary,
    onDismiss: () -> Unit,
    onSubmit: (amount: Double, sourceUsahaPot: String, targetPersonalPot: String, note: String) -> Unit
) {
    var amountStr by remember { mutableStateOf(summary.activeTalangan.toLong().toString()) }
    var selectedUsahaPot by remember { mutableStateOf("MODAL_USAHA") }
    var selectedPersonalPot by remember { mutableStateOf("KEBUTUHAN") }
    var note by remember { mutableStateOf("Pengembalian talangan project ${summary.project.title}") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("↩️ Kembalikan Talangan") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Project: ${summary.project.title}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Sisa Talangan Aktif: ${CurrencyFormat.formatRupiah(summary.activeTalangan)}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.SemiBold
                )

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Nominal Pengembalian (Rp)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Sumber Dana Usaha:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val usahaPots = listOf("MODAL_USAHA" to "Modal Usaha", "DANA_CADANGAN" to "Dana Cadangan")
                    items(usahaPots) { (key, label) ->
                        FilterChip(
                            selected = selectedUsahaPot == key,
                            onClick = { selectedUsahaPot = key },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                }

                Text("Tujuan Dompet Pribadi:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val pribPots = listOf("KEBUTUHAN" to "Kebutuhan", "BEBAS" to "Bebas", "TABUNGAN" to "Tabungan")
                    items(pribPots) { (key, label) ->
                        FilterChip(
                            selected = selectedPersonalPot == key,
                            onClick = { selectedPersonalPot = key },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Keterangan (opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountStr.toDoubleOrNull() ?: 0.0
                    if (amt > 0) {
                        onSubmit(amt, selectedUsahaPot, selectedPersonalPot, note.trim())
                    }
                },
                enabled = (amountStr.toDoubleOrNull() ?: 0.0) > 0
            ) {
                Text("Proses Pengembalian")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

