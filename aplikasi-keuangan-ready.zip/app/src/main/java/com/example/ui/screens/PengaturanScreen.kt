package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FinancialSettingsEntity
import com.example.util.CurrencyFormat

import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults

@Composable
fun PengaturanScreen(
    settings: FinancialSettingsEntity?,
    onSaveSettings: (FinancialSettingsEntity) -> Unit,
    onOpenCategoryManager: () -> Unit,
    onExportBackup: (onJsonReady: (String) -> Unit) -> Unit,
    onRestoreBackup: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentSettings = settings ?: FinancialSettingsEntity()

    // Form states
    var pKeb by remember(currentSettings) { mutableStateOf(currentSettings.pribadiKebutuhanPct.toInt().toString()) }
    var pTab by remember(currentSettings) { mutableStateOf(currentSettings.pribadiTabunganPct.toInt().toString()) }
    var pBeb by remember(currentSettings) { mutableStateOf(currentSettings.pribadiBebasPct.toInt().toString()) }
    var pDar by remember(currentSettings) { mutableStateOf(currentSettings.pribadiDanaDaruratPct.toInt().toString()) }

    var uPrib by remember(currentSettings) { mutableStateOf(currentSettings.usahaPribadiPct.toInt().toString()) }
    var uMod by remember(currentSettings) { mutableStateOf(currentSettings.usahaModalPct.toInt().toString()) }
    var uCad by remember(currentSettings) { mutableStateOf(currentSettings.usahaCadanganPct.toInt().toString()) }
    var uSed by remember(currentSettings) { mutableStateOf(currentSettings.usahaSedekahPct.toInt().toString()) }

    var jajanVal by remember(currentSettings) {
        val amount = if (currentSettings.weeklyJajanAmount > 0) currentSettings.weeklyJajanAmount else (currentSettings.dailyJajanAmount * 7.0).coerceAtLeast(49000.0)
        mutableStateOf(amount.toInt().toString())
    }
    var emergencyTargetVal by remember(currentSettings) { mutableStateOf(currentSettings.emergencyFundTarget.toLong().toString()) }
    var selectedThemeMode by remember(currentSettings) { mutableStateOf(currentSettings.themeMode) }
    var enableDueNotif by remember(currentSettings) { mutableStateOf(currentSettings.enableDueNotification) }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showRestoreConfirmDialog by remember { mutableStateOf(false) }
    var pendingRestoreJson by remember { mutableStateOf("") }

    // File launcher for Restore
    val restoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { stream ->
                    val json = stream.bufferedReader().readText()
                    pendingRestoreJson = json
                    showRestoreConfirmDialog = true
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal membaca file backup", Toast.LENGTH_SHORT).show()
            }
        }
    }

    if (showRestoreConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreConfirmDialog = false },
            title = { Text("Konfirmasi Restore Data") },
            text = { Text("Restore akan MENGGANTI seluruh data transaksi dan pengaturan saat ini. Lanjutkan?") },
            confirmButton = {
                Button(
                    onClick = {
                        showRestoreConfirmDialog = false
                        onRestoreBackup(pendingRestoreJson)
                    }
                ) {
                    Text("Ya, Restore")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreConfirmDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "⚙️ Pengaturan Keuangan",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.testTag("pengaturan_title")
            )
        }

        // Section: Mode Tampilan Tema (Gelap / Terang)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "🎨 Mode Tampilan Aplikasi",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemeOptionCard(
                            title = "Terang",
                            icon = "☀️",
                            isSelected = selectedThemeMode == "LIGHT",
                            onClick = {
                                selectedThemeMode = "LIGHT"
                                onSaveSettings(currentSettings.copy(themeMode = "LIGHT"))
                            },
                            modifier = Modifier.weight(1f).testTag("theme_light_button")
                        )
                        ThemeOptionCard(
                            title = "Gelap",
                            icon = "🌙",
                            isSelected = selectedThemeMode == "DARK",
                            onClick = {
                                selectedThemeMode = "DARK"
                                onSaveSettings(currentSettings.copy(themeMode = "DARK"))
                            },
                            modifier = Modifier.weight(1f).testTag("theme_dark_button")
                        )
                        ThemeOptionCard(
                            title = "Sistem",
                            icon = "📱",
                            isSelected = selectedThemeMode == "SYSTEM",
                            onClick = {
                                selectedThemeMode = "SYSTEM"
                                onSaveSettings(currentSettings.copy(themeMode = "SYSTEM"))
                            },
                            modifier = Modifier.weight(1f).testTag("theme_system_button")
                        )
                    }
                }
            }
        }

        // Section: Notifikasi Pinjaman
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "🔔 Notifikasi Pinjaman Jatuh Tempo",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Tampilkan peringatan di Beranda saat ada pinjaman yang belum lunas melewati tanggal jatuh tempo.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Switch(
                        checked = enableDueNotif,
                        onCheckedChange = {
                            enableDueNotif = it
                            onSaveSettings(currentSettings.copy(enableDueNotification = it))
                        },
                        modifier = Modifier.testTag("enable_due_notification_switch")
                    )
                }
            }
        }

        if (errorMessage != null) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(12.dp),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Section A: Pembagian Usaha
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("🌾 Pembagian Pemasukan Usaha (Wajib Total 100%)", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = uPrib,
                            onValueChange = { uPrib = it },
                            label = { Text("Ke Pribadi %") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = uMod,
                            onValueChange = { uMod = it },
                            label = { Text("Modal %") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = uCad,
                            onValueChange = { uCad = it },
                            label = { Text("Cadangan %") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = uSed,
                            onValueChange = { uSed = it },
                            label = { Text("Sedekah %") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    val totalU = (uPrib.toDoubleOrNull() ?: 0.0) + (uMod.toDoubleOrNull() ?: 0.0) + (uCad.toDoubleOrNull() ?: 0.0) + (uSed.toDoubleOrNull() ?: 0.0)
                    Text(
                        text = "Total: ${totalU.toInt()}% ${if (totalU == 100.0) "✅" else "⚠️ (harus 100%)"}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (totalU == 100.0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        // Section B: Pembagian Pribadi
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("👤 Pembagian Pemasukan Pribadi (Wajib Total 100%)", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = pKeb,
                            onValueChange = { pKeb = it },
                            label = { Text("Kebutuhan %") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = pTab,
                            onValueChange = { pTab = it },
                            label = { Text("Tabungan %") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = pBeb,
                            onValueChange = { pBeb = it },
                            label = { Text("Bebas %") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = pDar,
                            onValueChange = { pDar = it },
                            label = { Text("Dana Darurat %") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    val totalP = (pKeb.toDoubleOrNull() ?: 0.0) + (pTab.toDoubleOrNull() ?: 0.0) + (pBeb.toDoubleOrNull() ?: 0.0) + (pDar.toDoubleOrNull() ?: 0.0)
                    Text(
                        text = "Total: ${totalP.toInt()}% ${if (totalP == 100.0) "✅" else "⚠️ (harus 100%)"}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (totalP == 100.0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        // Section C & D: Uang Jajan Mingguan & Target Dana Darurat
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("🍜 Uang Jajan Mingguan & 🛡️ Target Dana Darurat", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                    Column {
                        OutlinedTextField(
                            value = jajanVal,
                            onValueChange = { jajanVal = it },
                            label = { Text("Nominal Uang Jajan Mingguan (Default Rp49.000)") },
                            prefix = { Text("Rp ") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        val jajanParsed = jajanVal.toDoubleOrNull() ?: 49000.0
                        Text(
                            text = "Setara ${CurrencyFormat.formatRupiah(jajanParsed / 7.0)} / hari. Diambil otomatis dari saldo Kebutuhan setiap minggu jika saldo tersedia.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                        )
                    }

                    OutlinedTextField(
                        value = emergencyTargetVal,
                        onValueChange = { emergencyTargetVal = it },
                        label = { Text("Target Dana Darurat (Default Rp30.000.000)") },
                        prefix = { Text("Rp ") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }
        }

        if (errorMessage != null) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }

        // Save Button
        item {
            Button(
                onClick = {
                    val pKebD = pKeb.toDoubleOrNull() ?: 0.0
                    val pTabD = pTab.toDoubleOrNull() ?: 0.0
                    val pBebD = pBeb.toDoubleOrNull() ?: 0.0
                    val pDarD = pDar.toDoubleOrNull() ?: 0.0

                    val uPribD = uPrib.toDoubleOrNull() ?: 0.0
                    val uModD = uMod.toDoubleOrNull() ?: 0.0
                    val uCadD = uCad.toDoubleOrNull() ?: 0.0
                    val uSedD = uSed.toDoubleOrNull() ?: 0.0

                    val jajanD = jajanVal.toDoubleOrNull() ?: 49000.0
                    val emD = emergencyTargetVal.toDoubleOrNull() ?: 30000000.0

                    if ((pKebD + pTabD + pBebD + pDarD) != 100.0) {
                        errorMessage = "Total Persentase Pribadi harus tepat 100%! (Saat ini: ${(pKebD + pTabD + pBebD + pDarD).toInt()}%)"
                        return@Button
                    }

                    if ((uPribD + uModD + uCadD + uSedD) != 100.0) {
                        errorMessage = "Total Persentase Usaha harus tepat 100%! (Saat ini: ${(uPribD + uModD + uCadD + uSedD).toInt()}%)"
                        return@Button
                    }

                    errorMessage = null
                    val updated = currentSettings.copy(
                        pribadiKebutuhanPct = pKebD,
                        pribadiTabunganPct = pTabD,
                        pribadiBebasPct = pBebD,
                        pribadiDanaDaruratPct = pDarD,
                        usahaPribadiPct = uPribD,
                        usahaModalPct = uModD,
                        usahaCadanganPct = uCadD,
                        usahaSedekahPct = uSedD,
                        weeklyJajanAmount = jajanD,
                        dailyJajanAmount = jajanD / 7.0,
                        emergencyFundTarget = emD,
                        themeMode = selectedThemeMode,
                        enableDueNotification = enableDueNotif
                    )
                    onSaveSettings(updated)
                    Toast.makeText(context, "Pengaturan berhasil disimpan!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_settings_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.height(8.dp))
                Text("SIMPAN PENGATURAN", fontWeight = FontWeight.Bold)
            }
        }

        // Manage Categories Button
        item {
            OutlinedButton(
                onClick = onOpenCategoryManager,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("manage_categories_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Category, contentDescription = null)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Kelola Kategori Transaksi", fontWeight = FontWeight.Bold)
            }
        }

        // Section: Backup & Restore
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("💾 Backup & Restore Data", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Cadangkan seluruh transaksi, kategori, dan pengaturan ke file lokal JSON, atau pulihkan dari file backup.", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                onExportBackup { json ->
                                    val sendIntent = android.content.Intent().apply {
                                        action = android.content.Intent.ACTION_SEND
                                        putExtra(android.content.Intent.EXTRA_TEXT, json)
                                        type = "text/plain"
                                    }
                                    val shareIntent = android.content.Intent.createChooser(sendIntent, "Simpan Backup JSON")
                                    context.startActivity(shareIntent)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Backup")
                        }

                        OutlinedButton(
                            onClick = {
                                restoreLauncher.launch("text/plain")
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Upload, contentDescription = null)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Restore")
                        }
                    }
                }
            }
        }

        // Section: Tentang Aplikasi & Identitas Pembuat
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_tentang_aplikasi"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "ℹ️ Tentang Aplikasi",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.align(Alignment.Start)
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "MAS TANI",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Catatan Keuangan Pribadi & Usaha",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "🌱 Dibuat oleh Mas Tani",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                    Text(
                        text = "Versi 1.0.0",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
private fun ThemeOptionCard(
    title: String,
    icon: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = icon, fontSize = 20.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
