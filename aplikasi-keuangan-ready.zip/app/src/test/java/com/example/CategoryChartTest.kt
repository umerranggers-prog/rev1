package com.example

import com.example.data.model.TransactionEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class CategoryChartTest {

    @Test
    fun testCategoryTransactionsGroupingAndFiltering() {
        val now = Calendar.getInstance().timeInMillis
        val tx1 = TransactionEntity(
            id = 1,
            systemType = "PRIBADI",
            transactionType = "PENGELUARAN",
            amount = 25000.0,
            categoryName = "Kebutuhan",
            dateMillis = now - 1000,
            dateString = "2026-10-29",
            timeString = "10:00",
            note = "Beli beras"
        )
        val tx2 = TransactionEntity(
            id = 2,
            systemType = "PRIBADI",
            transactionType = "PENGELUARAN",
            amount = 20000.0,
            categoryName = "Kebutuhan",
            dateMillis = now - 86400000,
            dateString = "2026-10-28",
            timeString = "14:30",
            note = "Beli bensin"
        )
        val tx3 = TransactionEntity(
            id = 3,
            systemType = "PRIBADI",
            transactionType = "PENGELUARAN",
            amount = 12000.0,
            categoryName = "Kebutuhan",
            dateMillis = now - 2 * 86400000,
            dateString = "2026-10-26",
            timeString = "08:15",
            note = "Beli sabun"
        )
        val tx4 = TransactionEntity(
            id = 4,
            systemType = "PRIBADI",
            transactionType = "PENGELUARAN",
            amount = 35000.0,
            categoryName = "Kebutuhan",
            dateMillis = now - 4 * 86400000,
            dateString = "2026-10-24",
            timeString = "17:00",
            note = "Belanja dapur"
        )
        val txOther = TransactionEntity(
            id = 5,
            systemType = "PRIBADI",
            transactionType = "PENGELUARAN",
            amount = 50000.0,
            categoryName = "Bebas",
            dateMillis = now - 500,
            dateString = "2026-10-29",
            timeString = "11:00",
            note = "Hiburan"
        )

        val allTransactions = listOf(tx1, tx2, tx3, tx4, txOther)

        // 1. Grouping for the chart:
        val categoryBreakdown = allTransactions
            .filter { it.transactionType == "PENGELUARAN" && it.systemType == "PRIBADI" }
            .groupBy { it.categoryName }
            .mapValues { entry -> entry.value.sumOf { it.amount } }

        val kebutuhanChartTotal = categoryBreakdown["Kebutuhan"] ?: 0.0
        assertEquals(92000.0, kebutuhanChartTotal, 0.001)

        // 2. Tapping the "Kebutuhan" category filter:
        val filteredCategoryTx = allTransactions
            .filter {
                it.systemType == "PRIBADI" &&
                it.transactionType == "PENGELUARAN" &&
                it.categoryName.equals("Kebutuhan", ignoreCase = true)
            }
            .sortedWith(
                compareByDescending<TransactionEntity> { it.dateMillis }
                    .thenByDescending { it.id }
            )

        // Ensure all 4 separate transactions exist (none are collapsed/lost)
        assertEquals(4, filteredCategoryTx.size)

        // Ensure the sum of detail transactions EXACTLY matches the chart value
        val detailTotal = filteredCategoryTx.sumOf { it.amount }
        assertEquals(kebutuhanChartTotal, detailTotal, 0.001)

        // Ensure sorted descending by date/time
        assertEquals("Beli beras", filteredCategoryTx[0].note)
        assertEquals("Beli bensin", filteredCategoryTx[1].note)
        assertEquals("Beli sabun", filteredCategoryTx[2].note)
        assertEquals("Belanja dapur", filteredCategoryTx[3].note)
    }
}
